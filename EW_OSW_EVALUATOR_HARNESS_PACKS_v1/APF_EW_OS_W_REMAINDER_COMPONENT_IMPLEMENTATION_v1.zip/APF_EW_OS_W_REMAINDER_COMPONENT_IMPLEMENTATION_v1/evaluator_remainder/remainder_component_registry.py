"""Required finite-remainder component ledger."""
from __future__ import annotations
from dataclasses import dataclass
from typing import List

@dataclass(frozen=True)
class RemainderComponent:
    name: str
    status: str
    required: bool = True
    source_declared: bool = False
    formula_implemented: bool = False
    covariance_declared: bool = False

REQUIRED_REMAINDER_COMPONENTS: List[RemainderComponent] = [
    RemainderComponent("W_transverse_self_energy", "pending_reviewed_formula"),
    RemainderComponent("Z_transverse_self_energy", "pending_reviewed_formula"),
    RemainderComponent("gamma_Z_mixing", "pending_reviewed_formula"),
    RemainderComponent("gamma_gamma_hadronic_residual", "pending_external_hadronic_ledger"),
    RemainderComponent("vertex_terms", "pending_reviewed_formula"),
    RemainderComponent("box_terms", "pending_reviewed_formula"),
    RemainderComponent("charged_Goldstone_loops", "pending_reviewed_formula"),
    RemainderComponent("neutral_Goldstone_loops", "pending_reviewed_formula"),
    RemainderComponent("ghost_loops", "pending_reviewed_formula"),
    RemainderComponent("gauge_boson_loops", "pending_reviewed_formula"),
    RemainderComponent("Higgs_loops", "pending_reviewed_formula"),
    RemainderComponent("tadpoles", "pending_convention_and_formula"),
    RemainderComponent("mass_charge_weak_angle_counterterms", "pending_counterterm_assembly"),
    RemainderComponent("higher_order_QCD_EW_screening", "pending_screening_ledger"),
]

def missing_components():
    return [c.name for c in REQUIRED_REMAINDER_COMPONENTS if c.required and not c.formula_implemented]
