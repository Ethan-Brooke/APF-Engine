"""Finite scalar-integral substrate for the OS-W reviewed-formula evaluator.

This module intentionally implements only real-branch finite scalar kernels.
It does not implement diagram coefficients or physical electroweak observables.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
from typing import Tuple

class ComplexBranchRequired(ValueError):
    """Raised when B0bar needs a complex-threshold branch convention."""

@dataclass(frozen=True)
class PVKernelResult:
    kernel: str
    value: float
    units: str
    convention: str
    target_consumed: bool = False


def _positive(name: str, value: float) -> float:
    v = float(value)
    if not math.isfinite(v) or v <= 0:
        raise ValueError(f"{name} must be finite and positive")
    return v


def A0bar_finite(m2: float, mu2: float) -> PVKernelResult:
    """Finite part A0bar = m^2 * (1 - log(m^2/mu^2))."""
    m2 = _positive("m2", m2)
    mu2 = _positive("mu2", mu2)
    value = m2 * (1.0 - math.log(m2 / mu2))
    return PVKernelResult(
        kernel="A0bar_finite",
        value=value,
        units="mass^2",
        convention="finite_part_A0bar=m2*(1-log(m2/mu2)); no target inputs",
    )


def B0bar_finite_below_threshold(s: float, m1sq: float, m2sq: float, mu2: float, n: int = 96) -> PVKernelResult:
    """Finite real-branch B0bar using Gauss-Legendre quadrature.

    B0bar = - int_0^1 log((x*m1sq + (1-x)*m2sq - x*(1-x)*s)/mu2) dx.
    If the logarithm argument crosses zero, a complex branch convention is required and
    this partial pack fails closed.
    """
    s = float(s)
    if not math.isfinite(s):
        raise ValueError("s must be finite")
    m1sq = _positive("m1sq", m1sq)
    m2sq = _positive("m2sq", m2sq)
    mu2 = _positive("mu2", mu2)
    # Use leggauss without numpy by falling back to a fixed Simpson grid? Simpler: Gauss-Legendre nodes via numpy if available.
    try:
        import numpy as np
        nodes, weights = np.polynomial.legendre.leggauss(int(n))
        xs = 0.5 * (nodes + 1.0)
        ws = 0.5 * weights
        acc = 0.0
        for x, w in zip(xs, ws):
            arg = x*m1sq + (1.0-x)*m2sq - x*(1.0-x)*s
            if arg <= 0 or not math.isfinite(float(arg)):
                raise ComplexBranchRequired("B0bar finite part requires complex branch convention for this input")
            acc += float(w) * math.log(float(arg) / mu2)
        value = -acc
    except ImportError:
        # Composite Simpson fallback with even n.
        n = max(100, int(n))
        if n % 2:
            n += 1
        h = 1.0 / n
        acc = 0.0
        for k in range(n + 1):
            x = k * h
            arg = x*m1sq + (1.0-x)*m2sq - x*(1.0-x)*s
            if arg <= 0 or not math.isfinite(arg):
                raise ComplexBranchRequired("B0bar finite part requires complex branch convention for this input")
            coeff = 4 if k % 2 else 2
            if k == 0 or k == n:
                coeff = 1
            acc += coeff * math.log(arg / mu2)
        value = -(h / 3.0) * acc
    return PVKernelResult(
        kernel="B0bar_finite_below_threshold",
        value=float(value),
        units="dimensionless",
        convention="finite_real_branch_Feynman_parameter_integral; complex branch not implemented; no target inputs",
    )
