"""Fail-closed OS-W finite remainder assembler."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Mapping, Any, List
from .remainder_component_registry import REQUIRED_REMAINDER_COMPONENTS, missing_components

class FormulaImplementationRequired(RuntimeError):
    """Raised when someone attempts to assemble Delta r_rem before formula coverage is complete."""

FORBIDDEN_INPUTS = {
    "measured_M_W_value",
    "DIZET_ZFITTER_aggregate_output",
    "published_total_SM_M_W_as_component_value",
    "fitted_counterterm",
    "post_hoc_tolerance",
    "four_over_5063_weak_angle_shortcut",
    "measured_sin2theta_eff",
}

@dataclass(frozen=True)
class RemainderAssemblyStatus:
    can_assemble: bool
    missing: List[str]
    target_consumed: bool
    export_delta_r_rem: int
    reason: str


def _guard_forbidden(input_card: Mapping[str, Any]) -> None:
    present = sorted(k for k in FORBIDDEN_INPUTS if k in input_card and input_card[k] is not None)
    if present:
        raise ValueError(f"Forbidden OS-W inputs present: {present}")


def assemble_delta_r_remainder(input_card: Mapping[str, Any], *, allow_partial: bool = False) -> RemainderAssemblyStatus:
    """Return fail-closed status; never returns a numeric Delta r_rem in v1."""
    _guard_forbidden(input_card)
    missing = missing_components()
    if missing and not allow_partial:
        raise FormulaImplementationRequired(
            "Cannot assemble Delta r_rem: reviewed formula families missing: " + ", ".join(missing)
        )
    return RemainderAssemblyStatus(
        can_assemble=False,
        missing=missing,
        target_consumed=False,
        export_delta_r_rem=0,
        reason="partial substrate only; formula families not implemented",
    )
