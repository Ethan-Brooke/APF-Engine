# APF EW OS-W Remainder Component Implementation v1

This pack is a **partial finite-remainder implementation gate** for the APF-internal OS-W route. It implements a finite Passarino--Veltman scalar substrate (`A0bar`, `B0bar` below threshold) and a fail-closed remainder-component assembler. It does **not** evaluate `DeltaRhobarW`, `Delta r_rem`, `Delta r_OS`, or `M_W`.

The purpose is to move from a reviewed-formula evaluator scaffold to a source-auditable substrate on which the missing finite remainder component formulae can be implemented without smuggling the frozen target interval.

## Positive exports

```text
Export_OSW_remainder_component_implementation_partial = 1
Export_OSW_finite_PV_scalar_substrate = 1
Export_OSW_remainder_component_status_ledger = 1
Export_OSW_remainder_assembler_fail_closed = 1
Export_OSW_runtime_forbidden_input_guard = 1
```

## Preserved non-claims

```text
Export_OSW_APF_internal_DeltaRhobarW_evaluated = 0
Export_OSW_APF_internal_delta_r_rem_evaluated = 0
Export_OSW_APF_internal_full_loop_derivation = 0
Export_numeric_MW_prediction_from_this_pack = 0
```

## Implemented here

```text
A0bar_finite(m2, mu2)
B0bar_finite_below_threshold(s, m1sq, m2sq, mu2)
fail-closed OSW remainder assembler
component-status ledger for 14 pending finite-remainder formula families
```
