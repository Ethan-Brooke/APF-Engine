# Finite PV substrate theorem

The implemented kernels provide finite scalar-integral building blocks for a future reviewed OS-W formula evaluator. They do not determine the diagram coefficients, counterterms, tadpole convention, or gauge-cancellation assembly.

Therefore:

\[
\operatorname{Export}_{\rm PV\ finite\ substrate}=1,
\qquad
\operatorname{Export}_{\rm OSW\ value}=0.
\]
