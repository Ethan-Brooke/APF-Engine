# OS-W finite-remainder boundary theorem

Let `K_PV` be a finite scalar-integral substrate and let `F_i` be the reviewed finite formula families required for the OS-W remainder. If `K_PV` is implemented but any required `F_i` is missing, then the remainder assembler must fail closed.

\[
K_{PV}=1,\quad \exists i:F_i=0
\quad\Rightarrow\quad
\operatorname{Export}_{\Delta r_{\rm rem}}=0.
\]

This is the boundary closed by this pack.
