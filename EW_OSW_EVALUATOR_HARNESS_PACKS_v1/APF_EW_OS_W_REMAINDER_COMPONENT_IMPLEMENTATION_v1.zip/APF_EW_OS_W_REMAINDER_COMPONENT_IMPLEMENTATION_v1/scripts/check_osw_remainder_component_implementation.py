#!/usr/bin/env python3
from pathlib import Path
import json, math, sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from evaluator_remainder import A0bar_finite, B0bar_finite_below_threshold, assemble_delta_r_remainder, FormulaImplementationRequired
from evaluator_remainder.pv_finite_integrals import ComplexBranchRequired
from evaluator_remainder.remainder_component_registry import missing_components

checks=[]
def check(name, cond):
    if not cond:
        raise AssertionError(name)
    checks.append(name)

ledger = json.loads((ROOT/'CLAIM_LEDGER.json').read_text())
exp = ledger['exports']
check('contract-positive-export', exp['Export_OSW_remainder_component_implementation_partial'] == 1)
check('pv-substrate-export', exp['Export_OSW_finite_PV_scalar_substrate'] == 1)
check('no-DeltaRhobarW-export', exp['Export_OSW_APF_internal_DeltaRhobarW_evaluated'] == 0)
check('no-deltarrem-export', exp['Export_OSW_APF_internal_delta_r_rem_evaluated'] == 0)
check('no-MW-export', exp['Export_numeric_MW_prediction_from_this_pack'] == 0)
check('forbidden-count', len(ledger['forbidden_inputs']) == 7)
check('pending-remainder-count', len(ledger['pending_remainder_component_formulae']) == 14)

# A0 validation
r = A0bar_finite(4.0, 1.0)
check('A0bar-target-not-consumed', r.target_consumed is False)
check('A0bar-value', abs(r.value - 4.0*(1.0-math.log(4.0))) < 1e-12)

# B0 validation
b = B0bar_finite_below_threshold(0.0, 4.0, 4.0, 1.0)
check('B0bar-target-not-consumed', b.target_consumed is False)
check('B0bar-equal-mass-s0', abs(b.value + math.log(4.0)) < 1e-10)
# symmetry
b12 = B0bar_finite_below_threshold(1.0, 4.0, 9.0, 1.0)
b21 = B0bar_finite_below_threshold(1.0, 9.0, 4.0, 1.0)
check('B0bar-mass-symmetry', abs(b12.value - b21.value) < 1e-10)
# threshold guard
try:
    B0bar_finite_below_threshold(100.0, 1.0, 1.0, 1.0)
    raise AssertionError('threshold guard failed')
except ComplexBranchRequired:
    checks.append('B0bar-complex-branch-fails-closed')

# assembler fail-closed
try:
    assemble_delta_r_remainder({'alpha0': 0.0072973525693})
    raise AssertionError('assembler should fail closed')
except FormulaImplementationRequired:
    checks.append('assembler-fails-closed-missing-formulae')

# forbidden input guard
try:
    assemble_delta_r_remainder({'measured_M_W_value': 80.377}, allow_partial=True)
    raise AssertionError('forbidden input guard failed')
except ValueError:
    checks.append('forbidden-input-guard')

check('missing-components-14', len(missing_components()) == 14)

# required files
for rel in [
    'docs/HONEST_NON_CLAIMS.md','docs/IMPLEMENTED_REMAINDER_SUBSTRATE.md',
    'theorem/OSW_REMAINDER_COMPONENT_BOUNDARY_THEOREM.md','tables/REMAINDER_COMPONENT_STATUS.csv',
    'ledgers/FORBIDDEN_INPUT_LEDGER.csv','paper_drop_in/EW_OSW_Remainder_Component_Implementation_DropIn_v1.tex'
]:
    check('file:'+rel, (ROOT/rel).exists())

print('EW_OS_W_REMAINDER_COMPONENT_IMPLEMENTATION_PASS')
print(f'checks={len(checks)}')
print('implemented_substrate_kernels=2')
print('carried_prior_component_kernels=2')
print('pending_remainder_formulae=14')
print('exports.value_evaluated=0')
print('next_gate=APF_EW_OS_W_FULL_REMAINDER_FORMULA_IMPLEMENTATION_v1')
