# Counterterm assembly boundary

The finite PV substrate is not the OS-W self-energy calculation. The physical value needs the renormalized on-shell assembly:

```text
bare diagram finite parts
+ Goldstone/ghost/gauge cancellations
+ tadpole convention
+ mass counterterms
+ charge counterterm
+ weak-angle counterterm
+ vertex and box terms
+ higher-order screening ledger
```

This pack deliberately stops before this assembly.
