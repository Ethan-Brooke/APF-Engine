# Implemented finite scalar substrate

The pack implements finite scalar integral kernels used by reviewed electroweak self-energy formulae.

## A0 finite part

\[
\bar A_0(m^2;\mu^2)=m^2\left(1-\log\frac{m^2}{\mu^2}\right).
\]

## B0 finite part, below threshold / real branch

\[
\bar B_0(s;m_1^2,m_2^2;\mu^2)=
-\int_0^1 dx\,\log\left(\frac{x m_1^2+(1-x)m_2^2-x(1-x)s}{\mu^2}\right).
\]

The implementation intentionally raises a typed exception if the argument crosses the real-branch threshold. The complex continuation belongs in the next formula implementation gate, where branch conventions and imaginary parts must be declared.
