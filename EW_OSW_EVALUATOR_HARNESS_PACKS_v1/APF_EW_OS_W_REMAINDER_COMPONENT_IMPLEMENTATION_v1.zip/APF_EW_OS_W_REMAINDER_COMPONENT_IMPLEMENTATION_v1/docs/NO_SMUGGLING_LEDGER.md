# No-smuggling ledger

Forbidden inputs:

```text
measured_M_W_value
DIZET_ZFITTER_aggregate_output
published_total_SM_M_W_as_component_value
fitted_counterterm
post_hoc_tolerance
four_over_5063_weak_angle_shortcut
measured_sin2theta_eff
```

Audit comparators retained as comparators only:

```text
DeltaRhobarW(M_Z) target interval: [-1.260, -1.136]
Delta r_rem^alpha interval: [0.003518, 0.003839]
Delta r_rem target interval: [0.009409, 0.009730]
```
