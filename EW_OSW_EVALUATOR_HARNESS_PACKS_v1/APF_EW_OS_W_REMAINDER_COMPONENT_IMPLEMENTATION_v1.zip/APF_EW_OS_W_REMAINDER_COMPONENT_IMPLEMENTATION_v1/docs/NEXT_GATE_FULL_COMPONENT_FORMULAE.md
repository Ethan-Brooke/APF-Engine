# Next gate: full component formula implementation

The next pack should implement reviewed formulae for the 14 pending finite-remainder families, one family at a time, using the finite PV substrate provided here.

Required next acceptance tests:

1. source citation for each reviewed formula;
2. declared branch / finite-part convention;
3. gauge-cancellation participation map;
4. counterterm participation map;
5. no target interval consumed;
6. covariance rule declared;
7. assembler still fails closed until all families are present.
