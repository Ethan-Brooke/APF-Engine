# Remainder component status

This pack implements the finite scalar substrate and the fail-closed assembler. It does not implement the reviewed diagram coefficients.

Pending formula families:

```text
W_transverse_self_energy
Z_transverse_self_energy
gamma_Z_mixing
gamma_gamma_hadronic_residual
vertex_terms
box_terms
charged_Goldstone_loops
neutral_Goldstone_loops
ghost_loops
gauge_boson_loops
Higgs_loops
tadpoles
mass_charge_weak_angle_counterterms
higher_order_QCD_EW_screening
```

The assembler refuses to produce `Delta r_rem` until every required family is present with declared source, finite-part convention, gauge cancellation status, counterterm participation, and covariance rule.
