# Honest non-claims

This pack does not provide an APF-internal electroweak prediction. It does not replace DIZET/ZFITTER. It does not compute a complete one-loop or multi-loop Standard Model value.

The finite scalar-integral substrate is necessary but not sufficient. A physical OS-W value still requires reviewed component formulae and their gauge/counterterm/tadpole assembly.

Forbidden outputs in this pack:

```text
DeltaRhobarW numerical value
Delta r_rem numerical value
Delta r_OS numerical value
M_W numerical prediction
full SM loop derivation
DIZET/ZFITTER replacement
fitted counterterm
```
