"""
Source-transcribed OS-W core equation kernels.

This module implements only algebraic expressions whose source cards are transcribed
in APF_EW_OS_W_SOURCE_TRANSCRIPTION_CORE_SLICE_v1. It refuses all target-derived inputs.
"""
from dataclasses import dataclass
import math

FORBIDDEN_KEYS = {
    "measured_M_W_value",
    "DIZET_ZFITTER_aggregate_output",
    "published_total_SM_M_W_as_component_value",
    "fitted_counterterm",
    "post_hoc_tolerance",
    "four_over_5063_weak_angle_shortcut",
    "measured_sin2theta_eff",
}

class ForbiddenInputError(ValueError):
    pass

class DomainError(ValueError):
    pass

def guard_forbidden_inputs(input_card: dict) -> None:
    present = [k for k in FORBIDDEN_KEYS if k in input_card and input_card[k] not in (None, False, "")]
    if present:
        raise ForbiddenInputError(f"forbidden OS-W target inputs present: {present}")

def solve_mw2_from_delta_r(MZ: float, alpha: float, Gmu: float, delta_r: float) -> float:
    """Eq. (4.40): algebraic MW^2 solve from an already-evaluated Delta r."""
    rad = 1.0 - (4.0 * math.pi * alpha / (math.sqrt(2.0) * Gmu * MZ * MZ)) * (1.0 + delta_r)
    if rad < 0:
        raise DomainError(f"negative W-mass radicand: {rad}")
    return 0.5 * MZ * MZ * (1.0 + math.sqrt(rad))

def delta_r_one_loop_assembly(SigmaTWW0_minus_deltaMW2_over_MW2: float,
                              delta_Ze: float,
                              delta_sW_over_sW: float,
                              deltaZ_mu: float,
                              deltaZ_e: float,
                              deltaZ_nu_mu: float,
                              deltaZ_nu_e: float,
                              delta_r_triangle: float,
                              delta_r_box: float) -> float:
    """Eq. (4.41) normalized assembly."""
    return (SigmaTWW0_minus_deltaMW2_over_MW2 + 2.0*delta_Ze - 2.0*delta_sW_over_sW
            + 0.5*(deltaZ_mu + deltaZ_e + deltaZ_nu_mu + deltaZ_nu_e)
            + delta_r_triangle + delta_r_box)

def delta_Ze_OS(PiAA0: float, SigmaTAZ0_over_MZ2: float, sW: float, cW: float, sign: float = 1.0) -> float:
    """Eqs. (4.42)-(4.43), with sign=+1 for SM convention."""
    return 0.5 * PiAA0 - sign * (sW / cW) * SigmaTAZ0_over_MZ2

def PiAA0_split(delta_alpha: float, RePiAA_f_MZ2: float, PiAA_rem0: float) -> float:
    """Eq. (4.44)."""
    return delta_alpha + RePiAA_f_MZ2 + PiAA_rem0

def delta_sW_OS(cW2: float, sW: float, deltaMZ2_over_MZ2: float, deltaMW2_over_MW2: float) -> float:
    """Eq. (4.45)."""
    return (cW2 / (2.0*sW)) * (deltaMZ2_over_MZ2 - deltaMW2_over_MW2)

def lepton_WF_counterterm(Sigma_ll_L_0: float) -> float:
    """Eq. (4.47): delta Z^l = - Sigma^L_ll(0)."""
    return -Sigma_ll_L_0

def delta_vb_SM(alpha: float, sW2: float, cW2: float) -> float:
    """Eq. (4.50)."""
    if sW2 <= 0 or cW2 <= 0:
        raise DomainError("sW2 and cW2 must be positive")
    return alpha/(4.0*math.pi*sW2) * (6.0 + ((7.0 - 4.0*sW2)/(2.0*sW2))*math.log(cW2))

def delta_r_SM_one_loop(delta_alpha: float,
                         cW2_over_sW2: float,
                         deltaMZ2_over_MZ2: float,
                         deltaMW2_over_MW2: float,
                         RePiAA_f_MZ2: float,
                         PiAA_rem0: float,
                         two_cW_over_sW_SigmaTAZ0_over_MZ2: float,
                         SigmaTWW0_minus_deltaMW2_over_MW2: float,
                         delta_vb_sm: float) -> float:
    """Eq. (4.51) normalized assembly."""
    return (delta_alpha - cW2_over_sW2*(deltaMZ2_over_MZ2 - deltaMW2_over_MW2)
            + RePiAA_f_MZ2 + PiAA_rem0 + two_cW_over_sW_SigmaTAZ0_over_MZ2
            + SigmaTWW0_minus_deltaMW2_over_MW2 + delta_vb_sm)

def delta_r_decomposition(delta_alpha: float, cW2_over_sW2: float, delta_rho1: float, delta_r_rem: float) -> float:
    """Eq. (4.52)."""
    return delta_alpha - cW2_over_sW2*delta_rho1 + delta_r_rem
