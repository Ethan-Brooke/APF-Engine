# dao_gabelmann_muehlleitner_2023_epjc_delta_r_os

Title: The O((alpha_t+alpha_lambda+alpha_kappa)^2) correction to the rho parameter and its effect on the W boson mass calculation in the complex NMSSM
Authors: Thi Nhung Dao, Martin Gabelmann, Margarete Mühlleitner
URL: https://link.springer.com/article/10.1140/epjc/s10052-023-12236-w
Type: open_access_epjc_reviewed_formula_source

Used for: Equation-level transcription of the on-shell Delta r relation, one-loop Delta r assembly, charge counterterm, weak-angle and mass counterterms, vertex/box combination, SM one-loop Delta r form, and higher-order SM correction family list.

Citation hint: Springer page lines 327-426
