# denner_dittmaier_2020_physrep_arxiv_1912_06823

Title: Electroweak Radiative Corrections for Collider Physics
Authors: Ansgar Denner and Stefan Dittmaier
URL: https://arxiv.org/abs/1912.06823
Type: modern_review_arxiv_physics_reports

Used for: Modern review/background for renormalization and one-loop techniques in collider EW calculations.

Citation hint: arXiv page lines 31-40, 51
