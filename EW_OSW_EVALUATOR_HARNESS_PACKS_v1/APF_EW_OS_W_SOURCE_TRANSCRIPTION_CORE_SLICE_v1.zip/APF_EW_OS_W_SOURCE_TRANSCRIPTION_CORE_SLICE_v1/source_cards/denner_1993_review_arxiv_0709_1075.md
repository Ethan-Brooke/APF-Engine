# denner_1993_review_arxiv_0709_1075

Title: Techniques for the calculation of electroweak radiative corrections at the one-loop level and results for W-physics at LEP200
Authors: Ansgar Denner
URL: https://arxiv.org/abs/0709.1075
Type: review_primary_arxiv

Used for: General EW one-loop/counterterm/scalar-integral source scaffold. The arXiv abstract states that the review gives Feynman rules, explicit counterterms, scalar one-loop integrals, tensor-reduction formulae, soft photonic corrections, and W-physics applications.

Citation hint: arXiv page lines 31-40, 51
