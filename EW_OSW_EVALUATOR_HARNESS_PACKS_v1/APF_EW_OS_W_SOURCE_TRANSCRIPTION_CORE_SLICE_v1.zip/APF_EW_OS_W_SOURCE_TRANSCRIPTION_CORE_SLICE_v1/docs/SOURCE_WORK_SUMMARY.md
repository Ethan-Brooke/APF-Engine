# Source work summary

The previous pack reached a hard stop: no remainder family values could be transcribed without source-certified equations. This pack begins that source work by taking the reviewed/open OS W formula slice far enough to normalize the core equation cards.

The key source-transcribed objects are:

1. The muon-lifetime relation defining Delta r and the algebraic W-mass solve.
2. The one-loop Delta r assembly in the on-shell scheme.
3. Charge, weak-angle, mass, and external-lepton counterterm cards.
4. The Fermi-model QED subtraction convention for muon-decay Delta r.
5. The analytic SM vertex/box/WF combination after the subtraction.
6. The source-level expression that collects the SM one-loop result.
7. The Sirlin-style splitting Delta r = Delta alpha - (c_W^2/s_W^2) Delta rho + Delta r_rem.
8. The higher-order SM family queue for future work.

This is a core-slice transcription, not a full remainder evaluation. The full finite remainder still needs source-certified values for 14 families.
