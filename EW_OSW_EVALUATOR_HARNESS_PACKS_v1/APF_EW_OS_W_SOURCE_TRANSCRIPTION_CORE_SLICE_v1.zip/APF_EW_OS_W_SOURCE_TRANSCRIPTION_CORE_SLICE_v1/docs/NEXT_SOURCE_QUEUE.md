# Next source queue

The next real source-work gate is one family with actual source-certified coefficient values, not another wrapper.

Recommended order:

1. W transverse self-energy finite expression.
2. Z transverse self-energy finite expression.
3. gamma-Z mixing at zero momentum.
4. mass/charge/weak-angle counterterm assembly cross-check.
5. vertex+box finite residual beyond the closed SM analytic delta_vb card.
6. Goldstone/gauge/ghost cancellation block.
7. Higgs/tadpole convention block.
8. higher-order QCD/EW screening families.

Every family needs: source reference, equation ID, symbol normalization, renormalization convention, target_consumed=false, and a fail-closed implementation.
