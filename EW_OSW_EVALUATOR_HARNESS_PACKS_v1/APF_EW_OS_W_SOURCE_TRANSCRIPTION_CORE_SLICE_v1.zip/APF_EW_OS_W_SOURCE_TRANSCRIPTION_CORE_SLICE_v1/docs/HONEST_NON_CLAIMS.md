# Honest non-claims

This pack does not claim any of the following:

- a numerical M_W prediction;
- an evaluated Delta r_OS;
- an evaluated Delta r_rem;
- an evaluated overline{Delta rho}_W;
- a DIZET/ZFITTER replacement;
- a fitted counterterm;
- a full APF-internal EW loop derivation;
- finite W/Z/gammaZ/gauge/Higgs/Goldstone/ghost/tadpole coefficient values.

The pack closes only a source-transcribed core equation slice and runtime algebraic kernels for equations whose inputs remain symbolic or separately supplied.
