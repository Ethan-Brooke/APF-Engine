#!/usr/bin/env python3
from pathlib import Path
import csv, json, math, sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from evaluator_source_slice.osw_source_transcribed_core import (
    guard_forbidden_inputs, ForbiddenInputError, solve_mw2_from_delta_r,
    delta_r_one_loop_assembly, delta_Ze_OS, PiAA0_split, delta_sW_OS,
    lepton_WF_counterterm, delta_vb_SM, delta_r_SM_one_loop, delta_r_decomposition
)

def assert_close(a, b, tol=1e-12):
    if abs(a-b) > tol:
        raise AssertionError(f"{a} != {b}")

def main():
    cards = list(csv.DictReader((ROOT/'equations'/'OSW_SOURCE_EQUATION_CARDS.csv').open()))
    if len(cards) != 13:
        raise AssertionError(f"expected 13 equation cards, found {len(cards)}")
    if not all(c['source_key'] for c in cards):
        raise AssertionError('missing source key')
    if any(c['export_value'] != 'no' for c in cards):
        raise AssertionError('all cards must export_value=no in this pack')
    refs = list(csv.DictReader((ROOT/'source_refs'/'SOURCE_REFERENCE_LEDGER.csv').open()))
    if len(refs) < 3:
        raise AssertionError('expected at least 3 source references')
    claim = json.loads((ROOT/'CLAIM_LEDGER.json').read_text())
    if claim['exports']['Export_OSW_source_transcription_core_slice'] != 1:
        raise AssertionError('source-transcription export missing')
    if claim['exports']['Export_OSW_APF_internal_delta_r_rem_evaluated'] != 0:
        raise AssertionError('delta_r_rem must remain non-exported')
    try:
        guard_forbidden_inputs({'measured_M_W_value':80.4})
        raise AssertionError('forbidden guard failed')
    except ForbiddenInputError:
        pass
    guard_forbidden_inputs({'M_Z':91.1876, 'alpha':1/137.035999, 'Gmu':1.1663787e-5})

    # Algebra checks using dummy symbolic values.
    assert solve_mw2_from_delta_r(91.1876, 1/137.035999, 1.1663787e-5, 0.0364) > 0
    assert_close(delta_Ze_OS(0.1, 0.02, 0.48, 0.88, 1), 0.05 - (0.48/0.88)*0.02)
    assert_close(PiAA0_split(0.03, 0.01, 0.002), 0.042)
    assert_close(delta_sW_OS(0.77, 0.48, 0.02, 0.01), (0.77/(2*0.48))*0.01)
    assert_close(lepton_WF_counterterm(0.123), -0.123)
    vb = delta_vb_SM(1/137.035999, 0.223, 0.777)
    if not math.isfinite(vb):
        raise AssertionError('delta_vb_SM not finite')
    dr41 = delta_r_one_loop_assembly(0.1,0.2,0.03,0.01,0.02,0.03,0.04,0.05,0.06)
    assert_close(dr41, 0.1 + 0.4 - 0.06 + 0.5*(0.01+0.02+0.03+0.04)+0.05+0.06)
    dr51 = delta_r_SM_one_loop(0.03, 3.4, 0.02, 0.01, 0.004, 0.005, 0.006, 0.007, vb)
    assert_close(dr51, 0.03 - 3.4*(0.01)+0.004+0.005+0.006+0.007+vb)
    dr52 = delta_r_decomposition(0.059, 3.4775, 0.0093, 0.0096)
    assert_close(dr52, 0.059 - 3.4775*0.0093 + 0.0096)

    print('EW_OS_W_SOURCE_TRANSCRIPTION_CORE_SLICE_PASS')
    print(f'equation_cards={len(cards)}')
    print(f'source_refs={len(refs)}')
    print('exports.value_evaluated=0')
    print('next_gate=APF_EW_OS_W_SOURCE_TRANSCRIBE_FIRST_REMAINDER_FAMILY_v1')

if __name__ == '__main__':
    main()
