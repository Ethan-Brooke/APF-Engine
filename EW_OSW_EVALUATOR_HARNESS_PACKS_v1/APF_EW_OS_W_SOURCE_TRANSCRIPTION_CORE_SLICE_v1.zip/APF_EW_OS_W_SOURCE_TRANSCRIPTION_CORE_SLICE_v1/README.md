# APF EW OS-W Source Transcription Core Slice v1

This pack does the first actual source-transcription work after the remainder-family hard stop.
It is not another empty scaffold: it transcribes a reviewed/open equation slice for the on-shell W/Delta-r route and implements the source-normalized algebraic kernels that do not require the remaining finite self-energy families.

## What this pack closes

- Source reference ledger for Denner 1993, Denner--Dittmaier 2020, and an open EPJC source with explicit OS \Delta r equations.
- Equation cards for the OS W relation, one-loop \Delta r assembly, charge counterterm, weak-angle counterterm, mass counterterms, QED subtraction convention, SM vertex/box combination, SM one-loop \Delta r, Sirlin-style decomposition, and higher-order family queue.
- Runtime kernels for the algebraic pieces: MW solve from evaluated \Delta r, \delta Z_e, \Pi^AA split, \delta s_W, lepton WF sign map, \delta_vb^SM, one-loop SM assembly, and \Deltalpha/\Deltaho/\Delta r_rem decomposition.

## What this pack refuses

It does **not** import finite W/Z/gammaZ/gauge/Higgs/Goldstone/ghost/tadpole coefficient values. It therefore does **not** evaluate \Delta r_rem, \overline{\Deltaho}_W, \Delta r_OS, or M_W.

## Verifier

Run:

```bash
python scripts/check_osw_source_transcription_core.py
```

Expected:

```text
EW_OS_W_SOURCE_TRANSCRIPTION_CORE_SLICE_PASS
```
