# OS-W reviewed-formula evaluator scaffold theorem

## Theorem

Given a declared on-shell renormalization scheme card, a complete 16-family diagram ledger, and a forbidden-input ledger, the OS-W APF-internal evaluator can be advanced from an abstract contract to a source-auditable runtime scaffold without evaluating a physics value.

## Proof sketch

1. The OS-W decomposition fixes the output slots: `Delta_alpha`, `Delta_rho`, and `Delta_r_rem`.
2. The diagram-family ledger fixes the minimum component coverage.
3. The scheme card fixes the finite-part, scale, subtraction, tadpole, and counterterm conventions required before numerical evaluation.
4. The no-smuggling ledger blocks target-consumption paths.
5. The runtime scaffold refuses numeric output until all component formula hooks are implemented.

Therefore the scaffold is a valid next gate: it makes implementation precise while preserving all non-claims about evaluated electroweak values.
