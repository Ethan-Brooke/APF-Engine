"""Placeholder scalar-integral module.

Passarino--Veltman scalar integrals are not implemented in this scaffold.
A later reviewed-formula pack must supply finite-part and scale conventions.
"""

class ScalarIntegralImplementationRequired(NotImplementedError):
    pass


def B0_finite_part(*args, **kwargs):
    raise ScalarIntegralImplementationRequired("B0 finite part not implemented in v1 scaffold")


def A0_finite_part(*args, **kwargs):
    raise ScalarIntegralImplementationRequired("A0 finite part not implemented in v1 scaffold")
