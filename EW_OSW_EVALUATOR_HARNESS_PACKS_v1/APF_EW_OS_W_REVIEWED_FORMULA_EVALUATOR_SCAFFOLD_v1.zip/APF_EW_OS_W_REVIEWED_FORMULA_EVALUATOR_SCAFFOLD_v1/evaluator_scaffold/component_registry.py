"""Component registry loader for OS-W reviewed formula evaluator scaffold."""
from __future__ import annotations
import csv
from pathlib import Path
from typing import List, Dict


def load_component_registry_csv(path: str | Path) -> List[Dict[str, str]]:
    with Path(path).open(newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))
