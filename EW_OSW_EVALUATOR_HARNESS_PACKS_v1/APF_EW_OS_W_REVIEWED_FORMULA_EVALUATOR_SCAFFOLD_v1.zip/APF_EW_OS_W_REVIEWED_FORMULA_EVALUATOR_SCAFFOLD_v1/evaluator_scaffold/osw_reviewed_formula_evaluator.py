"""Reviewed-formula evaluator scaffold for the OS-W APF-internal EW route.

This module intentionally refuses to produce electroweak numerical values until reviewed
component formulae are implemented and source-certified. It is a guardrail, not a calculation.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, List

REQUIRED_COMPONENTS: List[str] = [
    "running_alpha",
    "fermion_self_energy",
    "W_self_energy",
    "Z_self_energy",
    "gamma_gamma_vacuum_polarization",
    "gamma_Z_mixing",
    "vertex_terms",
    "box_terms",
    "charged_Goldstone_loops",
    "neutral_Goldstone_loops",
    "ghost_loops",
    "gauge_boson_loops",
    "Higgs_loops",
    "tadpoles",
    "mass_charge_weak_angle_counterterms",
    "higher_order_QCD_EW_screening_ledger",
]

FORBIDDEN_INPUTS = {
    "measured_M_W_value",
    "DIZET_ZFITTER_aggregate_output",
    "published_total_SM_M_W_as_component_value",
    "fitted_counterterm",
    "post_hoc_tolerance",
    "four_over_5063_weak_angle_shortcut",
    "measured_sin2theta_eff",
}

class ForbiddenInputError(ValueError):
    """Raised when a target-consuming or forbidden shortcut input is present."""

class FormulaImplementationRequired(RuntimeError):
    """Raised when a caller asks for numeric output before formulas are implemented."""

@dataclass(frozen=True)
class EWInputCard:
    scheme: str
    input_parameters: Dict[str, Any]
    target_consumed: bool = False
    scaffold_only: bool = True

@dataclass(frozen=True)
class ComponentSpec:
    component_family: str
    implementation_status: str = "reviewed_formula_not_implemented"
    source_citation: str | None = None

@dataclass(frozen=True)
class DeltaRResult:
    status: str
    target_consumed: bool
    numeric_value_exported: bool
    message: str
    missing_components: List[str]


def validate_no_forbidden_inputs(card: EWInputCard | Dict[str, Any]) -> None:
    if isinstance(card, dict):
        params = dict(card.get("input_parameters", {}))
        target_consumed = bool(card.get("target_consumed", False))
    else:
        params = dict(card.input_parameters)
        target_consumed = card.target_consumed
    if target_consumed:
        raise ForbiddenInputError("target_consumed must be False for OS-W APF-internal evaluator inputs")
    bad = sorted(FORBIDDEN_INPUTS.intersection(params.keys()))
    if bad:
        raise ForbiddenInputError(f"Forbidden target-consuming inputs present: {bad}")


def default_component_registry() -> List[ComponentSpec]:
    return [ComponentSpec(component_family=name) for name in REQUIRED_COMPONENTS]


def missing_or_unimplemented_components(components: Iterable[ComponentSpec | Dict[str, Any]]) -> List[str]:
    by_name: Dict[str, str] = {}
    for item in components:
        if isinstance(item, dict):
            name = item.get("component_family")
            status = item.get("implementation_status", "")
        else:
            name = item.component_family
            status = item.implementation_status
        if name:
            by_name[name] = status
    missing: List[str] = []
    for name in REQUIRED_COMPONENTS:
        if by_name.get(name) != "implemented_reviewed_formula":
            missing.append(name)
    return missing


def dry_run_scaffold(card: EWInputCard, components: Iterable[ComponentSpec | Dict[str, Any]] | None = None) -> DeltaRResult:
    validate_no_forbidden_inputs(card)
    comps = list(components) if components is not None else default_component_registry()
    missing = missing_or_unimplemented_components(comps)
    return DeltaRResult(
        status="scaffold_only_no_numeric_value",
        target_consumed=False,
        numeric_value_exported=False,
        message="Evaluator scaffold validated inputs but did not evaluate EW self-energy values.",
        missing_components=missing,
    )


def evaluate_delta_r_os(card: EWInputCard, components: Iterable[ComponentSpec | Dict[str, Any]] | None = None) -> DeltaRResult:
    """Evaluate Delta r only after all reviewed formulas are implemented.

    This scaffold intentionally raises FormulaImplementationRequired when any required
    component is missing or unimplemented. A later pack may replace the refusal with a
    source-certified reviewed formula implementation.
    """
    result = dry_run_scaffold(card, components)
    if result.missing_components:
        raise FormulaImplementationRequired(
            "Reviewed electroweak formulae are not implemented for: "
            + ", ".join(result.missing_components)
        )
    # Defensive: even if someone marks all components implemented, this pack has no formulas.
    raise FormulaImplementationRequired(
        "All components are marked implemented, but this v1 scaffold contains no numeric formula backend."
    )
