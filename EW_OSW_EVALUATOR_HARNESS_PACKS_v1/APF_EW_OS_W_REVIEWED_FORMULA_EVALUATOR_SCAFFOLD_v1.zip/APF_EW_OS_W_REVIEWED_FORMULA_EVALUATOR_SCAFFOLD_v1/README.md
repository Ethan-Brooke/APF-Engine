# APF_EW_OS_W_REVIEWED_FORMULA_EVALUATOR_SCAFFOLD_v1

This pack is Gate 3 for the OS-W APF-internal electroweak route: a reviewed-formula evaluator scaffold.
It does **not** evaluate the APF-internal electroweak remainder, it does **not** predict `M_W`, and it does **not** replace DIZET/ZFITTER.

The pack turns the prior contract and diagram-family ledger into a concrete API shape:

```text
EWInputCard + RenormalizationSchemeCard + ComponentFormulaRegistry
    -> reviewed component contributions
    -> DeltaRResult
```

but every physics component remains marked `reviewed_formula_not_implemented` until a later pack supplies source-certified formulae and citations.

## Positive exports

```text
Export_OSW_reviewed_formula_evaluator_scaffold = 1
Export_OSW_component_API_contract = 1
Export_OSW_no_smuggling_runtime_guards = 1
```

## Preserved non-claims

```text
Export_OSW_APF_internal_DeltaRhobarW_evaluated = 0
Export_OSW_APF_internal_delta_r_rem_evaluated = 0
Export_OSW_APF_internal_full_loop_derivation = 0
Export_numeric_MW_prediction_from_this_pack = 0
Export_DIZET_replacement_evaluator = 0
Export_reviewed_formula_coefficients_implemented = 0
```

## Required component families

- `running_alpha`
- `fermion_self_energy`
- `W_self_energy`
- `Z_self_energy`
- `gamma_gamma_vacuum_polarization`
- `gamma_Z_mixing`
- `vertex_terms`
- `box_terms`
- `charged_Goldstone_loops`
- `neutral_Goldstone_loops`
- `ghost_loops`
- `gauge_boson_loops`
- `Higgs_loops`
- `tadpoles`
- `mass_charge_weak_angle_counterterms`
- `higher_order_QCD_EW_screening_ledger`

## Forbidden inputs

- `measured_M_W_value`
- `DIZET_ZFITTER_aggregate_output`
- `published_total_SM_M_W_as_component_value`
- `fitted_counterterm`
- `post_hoc_tolerance`
- `four_over_5063_weak_angle_shortcut`
- `measured_sin2theta_eff`

The verifier checks that the scaffold refuses to produce a numeric value while components are incomplete, that all forbidden inputs are blocked, that all 16 diagram families are represented, and that the target intervals are present only as audit comparators.
