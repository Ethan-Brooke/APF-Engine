# Component formula map

Each component family must eventually supply four objects:

1. reviewed source citation;
2. analytic formula or reference implementation;
3. renormalization/counterterm dependencies;
4. benchmark behavior under declared input cards.

The present pack supplies only the row structure and runtime hooks.

| Component | Contribution slot | Status |
|---|---|---|
| `running_alpha` | OS-W reviewed component ledger | `reviewed_formula_not_implemented` |
| `fermion_self_energy` | OS-W reviewed component ledger | `reviewed_formula_not_implemented` |
| `W_self_energy` | OS-W reviewed component ledger | `reviewed_formula_not_implemented` |
| `Z_self_energy` | OS-W reviewed component ledger | `reviewed_formula_not_implemented` |
| `gamma_gamma_vacuum_polarization` | OS-W reviewed component ledger | `reviewed_formula_not_implemented` |
| `gamma_Z_mixing` | OS-W reviewed component ledger | `reviewed_formula_not_implemented` |
| `vertex_terms` | OS-W reviewed component ledger | `reviewed_formula_not_implemented` |
| `box_terms` | OS-W reviewed component ledger | `reviewed_formula_not_implemented` |
| `charged_Goldstone_loops` | OS-W reviewed component ledger | `reviewed_formula_not_implemented` |
| `neutral_Goldstone_loops` | OS-W reviewed component ledger | `reviewed_formula_not_implemented` |
| `ghost_loops` | OS-W reviewed component ledger | `reviewed_formula_not_implemented` |
| `gauge_boson_loops` | OS-W reviewed component ledger | `reviewed_formula_not_implemented` |
| `Higgs_loops` | OS-W reviewed component ledger | `reviewed_formula_not_implemented` |
| `tadpoles` | OS-W reviewed component ledger | `reviewed_formula_not_implemented` |
| `mass_charge_weak_angle_counterterms` | OS-W reviewed component ledger | `reviewed_formula_not_implemented` |
| `higher_order_QCD_EW_screening_ledger` | OS-W reviewed component ledger | `reviewed_formula_not_implemented` |
