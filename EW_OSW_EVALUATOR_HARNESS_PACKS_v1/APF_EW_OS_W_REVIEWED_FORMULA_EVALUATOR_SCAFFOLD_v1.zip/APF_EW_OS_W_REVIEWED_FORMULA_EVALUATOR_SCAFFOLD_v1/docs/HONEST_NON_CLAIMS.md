# Honest non-claims

This pack does not evaluate the electroweak self-energy.
It does not compute `Delta_r_rem`.
It does not compute `DeltaRhobarW`.
It does not predict `M_W`.
It does not replace DIZET/ZFITTER.
It does not implement Denner/Sirlin formulae.
It does not derive electroweak diagram coefficients internally.

Its positive claim is narrower: the reviewed-formula evaluator now has a concrete scaffold and runtime refusal discipline.
