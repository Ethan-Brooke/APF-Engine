# Allowed reviewed-formula imports

Allowed imports in the next gate are component-level reviewed formulae and their finite-part conventions. Aggregate black-box outputs are not allowed.

Allowed:

- published analytic one-loop self-energy formulae;
- published counterterm relations;
- published Passarino--Veltman finite-part conventions;
- published tadpole convention choices;
- published QCD/EW screening factors when entered as named external content.

Forbidden:

- measured W mass as an input;
- DIZET/ZFITTER aggregate outputs;
- total published Standard-Model W prediction as a component;
- target-window back-solving;
- fitted finite counterterm;
- APF weak-angle shortcut as substitute for loop calculation.
