# No-smuggling protocol

The evaluator must fail closed if an input card contains any of:

```text
measured_M_W_value
DIZET_ZFITTER_aggregate_output
published_total_SM_M_W_as_component_value
fitted_counterterm
post_hoc_tolerance
four_over_5063_weak_angle_shortcut
measured_sin2theta_eff
```

The target windows are allowed only in benchmark metadata with `role = audit_comparator_only`.
They may not be read by the evaluator path.
