# Reviewed-formula evaluator scaffold specification

## Purpose

This pack defines the runtime shape of an OS-W reviewed-formula evaluator without implementing the reviewed electroweak formulae. It exists to prevent a repeat of the diagnostic-scalar failure mode: a locally runnable helper may not be treated as an electroweak component unless the full renormalized formula convention is explicit.

## API target

```python
evaluate_delta_r_os(
    input_card: EWInputCard,
    scheme_card: RenormalizationSchemeCard,
    component_registry: ComponentFormulaRegistry,
) -> DeltaRResult
```

The evaluator decomposes

\[
\Delta r_{m OS}
= \Deltalpha - rac{c_W^2}{s_W^2}\Deltaho + \Delta r_{m rem}.
\]

## Scaffold status

The API exists. Numeric formulae do not. Each component family carries a `reviewed_formula_not_implemented` status. The evaluator must refuse to output `Delta_r_total`, `Delta_r_rem`, `DeltaRhobarW`, or `M_W` until every required component is implemented, source-cited, and gauge/counterterm validated.

## Runtime refusal condition

If any component has `implementation_status != implemented_reviewed_formula`, the evaluator raises `FormulaImplementationRequired` and returns no physics value.

## Promotion gate

The next pack may promote only to reviewed-formula benchmark grade, not APF-internal full-loop derivation, unless APF derives diagram coefficients rather than importing them from the reviewed literature.
