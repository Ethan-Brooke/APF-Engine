# Benchmark and validation protocol

The scaffold carries benchmark intervals only as audit comparators.

A future implementation must report:

```text
Delta_alpha
Delta_rho
Delta_r_rem
Delta_r_total
DeltaRhobarW
finite_part_ledger
scale_ledger
counterterm_ledger
covariance
Ward_ST_identity_status
target_consumed = false
```

Validation gates:

1. all 16 component families implemented;
2. no forbidden inputs present;
3. scheme card is on-shell and internally consistent;
4. tadpole convention declared;
5. Goldstone/ghost/gauge cancellation gate passes;
6. component covariance propagated;
7. target intervals used only after evaluation as audit comparators.

This pack does not run those physics benchmarks because no formulae are implemented here.
