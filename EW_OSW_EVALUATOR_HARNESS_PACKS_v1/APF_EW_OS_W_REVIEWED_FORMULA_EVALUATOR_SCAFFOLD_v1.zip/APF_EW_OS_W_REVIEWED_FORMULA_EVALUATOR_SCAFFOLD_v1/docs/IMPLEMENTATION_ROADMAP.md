# Implementation roadmap

## Gate 3a — This pack

Scaffold API + runtime refusal discipline.

## Gate 3b — Component implementation

Implement reviewed formulae component-by-component. Each row must carry source, convention, input dependencies, and unit tests.

## Gate 3c — Reviewed evaluator benchmark

Run the complete reviewed evaluator against declared input cards. Compare to frozen target intervals only after evaluation.

## Gate 4 — APF-internal route evaluation

Promote only if target-consumption guards pass and covariance is propagated.

## Gate 5 — APF-internal full-loop derivation

Not available unless diagram coefficients are derived by APF rather than imported from reviewed formulae.
