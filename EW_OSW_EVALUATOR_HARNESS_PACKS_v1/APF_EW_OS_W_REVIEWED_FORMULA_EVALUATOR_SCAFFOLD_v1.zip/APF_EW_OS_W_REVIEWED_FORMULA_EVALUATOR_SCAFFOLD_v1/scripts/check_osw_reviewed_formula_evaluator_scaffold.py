#!/usr/bin/env python3
from __future__ import annotations
import json, csv, sys, importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIRED_COMPONENTS = [
    'running_alpha','fermion_self_energy','W_self_energy','Z_self_energy',
    'gamma_gamma_vacuum_polarization','gamma_Z_mixing','vertex_terms','box_terms',
    'charged_Goldstone_loops','neutral_Goldstone_loops','ghost_loops','gauge_boson_loops',
    'Higgs_loops','tadpoles','mass_charge_weak_angle_counterterms','higher_order_QCD_EW_screening_ledger'
]
FORBIDDEN_INPUTS = {
    'measured_M_W_value','DIZET_ZFITTER_aggregate_output','published_total_SM_M_W_as_component_value',
    'fitted_counterterm','post_hoc_tolerance','four_over_5063_weak_angle_shortcut','measured_sin2theta_eff'
}

def load_json(p):
    return json.loads((ROOT/p).read_text(encoding='utf-8'))

def assert_true(cond, msg):
    if not cond:
        raise AssertionError(msg)

def main():
    claim = load_json('CLAIM_LEDGER.json')
    exports = claim['exports']
    assert_true(exports['Export_OSW_reviewed_formula_evaluator_scaffold'] == 1, 'scaffold export missing')
    assert_true(exports['Export_OSW_APF_internal_delta_r_rem_evaluated'] == 0, 'delta_r_rem must remain unevaluated')
    assert_true(exports['Export_numeric_MW_prediction_from_this_pack'] == 0, 'M_W prediction must remain zero')
    assert_true(claim['target_intervals_audit_comparator_only']['DeltaRhobarW_MZ'] == [-1.260, -1.136], 'target interval drift')
    assert_true(set(claim['forbidden_inputs']) == FORBIDDEN_INPUTS, 'forbidden input set drift')

    rows = list(csv.DictReader((ROOT/'ledgers/COMPONENT_FORMULA_REGISTRY.csv').open(encoding='utf-8')))
    names = [r['component_family'] for r in rows]
    assert_true(names == REQUIRED_COMPONENTS, 'component list mismatch')
    assert_true(all(r['implementation_status'] == 'reviewed_formula_not_implemented' for r in rows), 'components must not be implemented in scaffold')

    forbid_rows = list(csv.DictReader((ROOT/'ledgers/FORBIDDEN_INPUT_LEDGER.csv').open(encoding='utf-8')))
    assert_true({r['forbidden_key'] for r in forbid_rows} == FORBIDDEN_INPUTS, 'forbidden CSV mismatch')

    # Import scaffold directly from file and test refusal behavior.
    mod_path = ROOT/'evaluator_scaffold/osw_reviewed_formula_evaluator.py'
    spec = importlib.util.spec_from_file_location('osw_reviewed_formula_evaluator', mod_path)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)

    valid = load_json('fixtures/valid_scaffold_input_card.json')
    card = mod.EWInputCard(**valid)
    dry = mod.dry_run_scaffold(card)
    assert_true(dry.numeric_value_exported is False, 'dry run exported a numeric value')
    assert_true(len(dry.missing_components) == 16, 'dry run should report all 16 components missing')

    try:
        mod.evaluate_delta_r_os(card)
    except mod.FormulaImplementationRequired:
        pass
    else:
        raise AssertionError('evaluate_delta_r_os must fail closed in scaffold')

    invalid = load_json('fixtures/invalid_forbidden_input_card.json')
    bad_card = mod.EWInputCard(**invalid)
    try:
        mod.validate_no_forbidden_inputs(bad_card)
    except mod.ForbiddenInputError:
        pass
    else:
        raise AssertionError('forbidden input was not blocked')

    # Ensure schemas exist and are JSON.
    for p in ['schemas/EWInputCard.schema.json','schemas/ComponentFormulaRegistry.schema.json','schemas/DeltaRResult.schema.json']:
        load_json(p)

    print('EW_OS_W_REVIEWED_FORMULA_EVALUATOR_SCAFFOLD_PASS')
    print('component_families=16')
    print('forbidden_inputs=7')
    print('exports.value_evaluated=0')
    print('next_gate=reviewed_formula_component_implementation')

if __name__ == '__main__':
    main()
