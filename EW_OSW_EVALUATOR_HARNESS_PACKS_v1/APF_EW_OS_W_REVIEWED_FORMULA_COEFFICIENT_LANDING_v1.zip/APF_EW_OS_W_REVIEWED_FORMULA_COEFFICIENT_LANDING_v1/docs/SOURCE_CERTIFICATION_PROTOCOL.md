# Source Certification Protocol

A coefficient family can move from `source_required` to `source_certified` only if it provides:

1. reviewed source citation or explicitly declared external import;
2. formula transcription with equation identifier;
3. on-shell scheme compatibility;
4. finite-part convention;
5. renormalization-scale convention;
6. tadpole/counterterm convention match;
7. gauge-parameter handling and cancellation membership;
8. covariance / truncation policy;
9. forbidden-input proof.

Forbidden-input proof must assert that the coefficient was not inferred from measured `M_W`, aggregate DIZET/ZFITTER outputs, published total SM `M_W`, fitted counterterms, post-hoc tolerances, the `4/5063` weak-angle shortcut, or measured `sin^2(theta_eff)`.
