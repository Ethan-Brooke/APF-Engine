# Coefficient Normalization Convention

All coefficient cards must declare the normalization in which their formula contributes to:

\[
\Delta r_{m OS} = \Deltalpha - rac{c_W^2}{s_W^2}\Deltaho + \Delta r_{m rem}.
\]

The required normalization fields are:

```text
component_family
renormalization_scheme
finite_part_convention
mu_scale_policy
alpha_input_policy
mass_input_policy
weak_angle_policy
contribution_dimension
sign_convention
counterterm_membership
cancellation_group
```

A coefficient with missing sign convention or cancellation-group membership is not evaluable.
