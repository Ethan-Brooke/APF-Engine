# Honest Non-Claims

This pack does not claim:

- an evaluated APF-internal `DeltaRhobarW`;
- an evaluated APF-internal `Delta_r_rem`;
- a full `Delta r_OS` value;
- a numerical W-mass prediction;
- a replacement for DIZET/ZFITTER;
- APF-internal derivation of reviewed electroweak loop coefficients;
- fitted counterterms or post-hoc tolerance tuning.

The two carried component kernels are limited prior components. Every finite-remainder coefficient family still requires a source-certified formula card before evaluation.
