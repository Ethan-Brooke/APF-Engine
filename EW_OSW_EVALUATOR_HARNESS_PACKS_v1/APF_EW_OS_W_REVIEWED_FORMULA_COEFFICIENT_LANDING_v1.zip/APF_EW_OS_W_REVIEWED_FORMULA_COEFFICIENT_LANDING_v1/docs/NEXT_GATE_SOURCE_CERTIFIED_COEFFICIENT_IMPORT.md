# Next Gate: Source-Certified Coefficient Import

The next legitimate push is source-certified import for one or more coefficient families. Recommended order:

1. W/Z transverse self-energy finite coefficients;
2. gamma-Z mixing;
3. vertex and box terms;
4. Goldstone/ghost/gauge cancellation groups;
5. Higgs/tadpole convention;
6. counterterm assembly;
7. hadronic residual and higher-order policy.

Do not attempt a total `Delta r_rem` until all cancellation groups and counterterm memberships are closed.
