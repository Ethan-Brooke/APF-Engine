# Target Consumption Guard

The following target windows remain audit comparators, not coefficient sources:

\[
\overline{\Deltaho}_W(M_Z)\in[-1.260,-1.136],
\]

\[
\overline{\Delta r}_{m rem}^{lpha}\in[0.003518,0.003839],
\]

\[
\Delta r_{m rem,target}\in[0.009409,0.009730].
\]

A source card that uses any target interval to set, choose, normalize, fit, or accept a coefficient fails the verifier.
