"""Fail-closed OS-W reviewed-formula coefficient registry.

This module does not evaluate Delta r. It only validates whether coefficient
source cards are present, source-certified, and free of forbidden target inputs.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional

FORBIDDEN_INPUTS = {
    "measured_M_W_value",
    "DIZET_ZFITTER_aggregate_output",
    "published_total_SM_M_W_as_component_value",
    "fitted_counterterm",
    "post_hoc_tolerance",
    "four_over_5063_weak_angle_shortcut",
    "measured_sin2theta_eff",
}

REQUIRED_FIELDS = {
    "family",
    "source_kind",
    "reviewed_source",
    "equation_id",
    "scheme",
    "finite_part_convention",
    "scale_policy",
    "sign_convention",
    "counterterm_membership",
    "cancellation_group",
    "target_consumed",
}

class CoefficientSourceRequired(RuntimeError):
    pass

class ForbiddenInputConsumed(ValueError):
    pass

class InvalidCoefficientSourceCard(ValueError):
    pass

@dataclass(frozen=True)
class CoefficientSourceCard:
    family: str
    source_kind: str
    reviewed_source: str
    equation_id: str
    scheme: str
    finite_part_convention: str
    scale_policy: str
    sign_convention: str
    counterterm_membership: str
    cancellation_group: str
    target_consumed: bool = False
    consumed_inputs: List[str] = field(default_factory=list)
    coefficient_status: str = "source_required"

    def validate(self) -> None:
        bad = sorted(set(self.consumed_inputs) & FORBIDDEN_INPUTS)
        if bad or self.target_consumed:
            raise ForbiddenInputConsumed(
                f"Coefficient card for {self.family} consumed forbidden target inputs: {bad}"
            )
        if self.scheme.lower() not in {"on_shell", "on-shell", "os"}:
            raise InvalidCoefficientSourceCard(f"{self.family}: expected on-shell scheme")
        for name in [
            self.reviewed_source,
            self.equation_id,
            self.finite_part_convention,
            self.scale_policy,
            self.sign_convention,
            self.counterterm_membership,
            self.cancellation_group,
        ]:
            if not name or str(name).strip().lower() in {"", "tbd", "missing", "unknown"}:
                raise InvalidCoefficientSourceCard(f"{self.family}: incomplete source card")

@dataclass
class CoefficientRegistry:
    required_families: List[str]
    cards: Dict[str, CoefficientSourceCard] = field(default_factory=dict)

    def add(self, card: CoefficientSourceCard) -> None:
        card.validate()
        self.cards[card.family] = card

    def missing(self) -> List[str]:
        return [fam for fam in self.required_families if fam not in self.cards]

    def assert_complete(self) -> None:
        missing = self.missing()
        if missing:
            raise CoefficientSourceRequired(
                "OS-W coefficient registry is not evaluable; missing source cards: "
                + ", ".join(missing)
            )

def default_required_families() -> List[str]:
    return [
        "W_transverse_self_energy",
        "Z_transverse_self_energy",
        "gamma_Z_mixing",
        "gamma_gamma_hadronic_residual",
        "vertex_terms",
        "box_terms",
        "charged_Goldstone_loops",
        "neutral_Goldstone_loops",
        "ghost_loops",
        "gauge_boson_loops",
        "Higgs_loops",
        "tadpoles",
        "mass_charge_weak_angle_counterterms",
        "higher_order_QCD_EW_screening",
    ]
