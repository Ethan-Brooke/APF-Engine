#!/usr/bin/env python3
from pathlib import Path
import csv, json, importlib.util, sys
ROOT = Path(__file__).resolve().parents[1]
claim = json.loads((ROOT/'CLAIM_LEDGER.json').read_text())
assert claim['exports']['Export_OSW_reviewed_formula_coefficient_landing_ledger'] == 1
assert claim['exports']['Export_OSW_APF_internal_delta_r_rem_evaluated'] == 0
assert claim['exports']['Export_numeric_MW_prediction_from_this_pack'] == 0
rows = list(csv.DictReader((ROOT/'ledgers/COEFFICIENT_SLOT_LEDGER.csv').open()))
assert len(rows) == 16, len(rows)
assert sum(r['status']=='implemented_prior_component' for r in rows) == 2
assert sum(r['target_consumed']=='true' for r in rows) == 0
forbidden = list(csv.DictReader((ROOT/'ledgers/FORBIDDEN_INPUT_LEDGER.csv').open()))
assert len(forbidden) == 7
# import loader and test fail-closed behavior
spec = importlib.util.spec_from_file_location('osw_coeff', ROOT/'evaluator_coefficients/osw_coefficient_registry.py')
mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)
reg = mod.CoefficientRegistry(required_families=mod.default_required_families())
try:
    reg.assert_complete()
    raise AssertionError('registry did not fail closed')
except mod.CoefficientSourceRequired:
    pass
valid = json.loads((ROOT/'fixtures/valid_coefficient_source_card_fixture.json').read_text())
card = mod.CoefficientSourceCard(**valid)
card.validate()
invalid = json.loads((ROOT/'fixtures/invalid_forbidden_input_source_card_fixture.json').read_text())
try:
    mod.CoefficientSourceCard(**invalid).validate()
    raise AssertionError('forbidden input was accepted')
except mod.ForbiddenInputConsumed:
    pass
print('EW_OS_W_REVIEWED_FORMULA_COEFFICIENT_LANDING_PASS')
print('coefficient_slots=16')
print('prior_components_carried=2')
print('source_required_slots=14')
print('forbidden_inputs=7')
print('exports.value_evaluated=0')
print('next_gate=APF_EW_OS_W_SOURCE_CERTIFIED_COEFFICIENT_IMPORT_v1')
