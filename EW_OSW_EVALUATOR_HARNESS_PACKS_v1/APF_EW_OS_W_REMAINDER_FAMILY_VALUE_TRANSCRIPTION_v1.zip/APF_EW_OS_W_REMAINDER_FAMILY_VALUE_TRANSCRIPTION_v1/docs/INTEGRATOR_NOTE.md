
# Integrator Note

Land this pack after `APF_EW_OS_W_FAMILY_BY_FAMILY_COEFFICIENT_VALUE_IMPORT_v1`.

The useful integration object is `transcription/osw_remainder_family_value_transcription.py`.
It must fail closed until all 14 finite-remainder family values have source-certified cards.

The correct outcome of this pack in runtime is `FormulaValueRequired`, not a number.
