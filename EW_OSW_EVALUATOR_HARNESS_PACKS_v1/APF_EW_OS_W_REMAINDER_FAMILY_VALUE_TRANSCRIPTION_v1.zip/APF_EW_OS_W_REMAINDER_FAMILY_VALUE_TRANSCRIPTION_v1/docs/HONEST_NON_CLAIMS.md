
# Honest Non-Claims

This pack does not evaluate any electroweak observable.

It does not export:

- `DeltaRhobarW`;
- `Delta_r_rem`;
- `Delta_r_OS`;
- a numerical W mass;
- a DIZET/ZFITTER replacement;
- fitted counterterms;
- a full APF-internal loop derivation.

All target windows are retained as audit comparators only and are forbidden as inputs to the evaluator.
