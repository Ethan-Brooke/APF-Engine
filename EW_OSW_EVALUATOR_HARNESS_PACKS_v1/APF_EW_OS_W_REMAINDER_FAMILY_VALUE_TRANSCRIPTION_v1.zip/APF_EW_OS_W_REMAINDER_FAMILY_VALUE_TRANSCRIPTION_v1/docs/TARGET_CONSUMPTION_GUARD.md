
# Target Consumption Guard

The following may appear only as audit comparators:

- `DeltaRhobarW(M_Z) in [-1.260, -1.136]`;
- `Delta_r_rem_alpha in [0.003518, 0.003839]`;
- `Delta_r_rem_target in [0.009409, 0.009730]`.

They may not appear in coefficient cards, counterterms, fitted constants, finite-part choices, tolerances, or source-normalization decisions.
