
# Remainder Family Value Transcription Protocol

A finite-remainder family value card is valid only when it supplies:

1. family name from the 14-family OS-W finite-remainder list;
2. reviewed source reference;
3. equation number or stable equation locator;
4. exact symbolic expression or coefficient table;
5. symbol dictionary mapping source notation into APF OS-W notation;
6. renormalization scheme and scale convention;
7. finite-part convention;
8. tadpole convention if the family touches mass or Higgs-sector renormalization;
9. Goldstone/ghost/gauge cancellation membership if applicable;
10. covariance or uncertainty rule;
11. target-consumption declaration set to false;
12. forbidden-input scan passing.

The pack intentionally ships zero transcribed finite-remainder values. Its claim is the boundary protocol and fail-closed loader, not the numerical evaluator.
