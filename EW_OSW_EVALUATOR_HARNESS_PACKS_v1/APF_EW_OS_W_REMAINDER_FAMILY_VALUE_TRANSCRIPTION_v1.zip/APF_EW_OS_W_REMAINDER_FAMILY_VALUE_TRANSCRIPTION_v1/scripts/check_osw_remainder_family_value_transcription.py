
#!/usr/bin/env python3
from pathlib import Path
import csv, json, sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from transcription.osw_remainder_family_value_transcription import load_cards, assemble_remainder, FormulaValueRequired, ForbiddenInputError, REQUIRED_FAMILIES, FORBIDDEN_INPUTS

def assert_true(cond, msg):
    if not cond:
        raise AssertionError(msg)

checks = []
claim = json.loads((ROOT/'CLAIM_LEDGER.json').read_text())
assert_true(claim['exports']['Export_OSW_APF_internal_delta_r_rem_evaluated'] == 0, 'delta_r_rem export must be 0')
checks.append('export nonclaim preserved')
assert_true(claim['counts']['remainder_families'] == 14, 'must have 14 families')
checks.append('family count')
rows = list(csv.DictReader((ROOT/'ledgers'/'REMAINDER_FAMILY_VALUE_TRANSCRIPTION_CARDS.csv').open()))
assert_true(len(rows) == 14, 'ledger must have 14 rows')
assert_true({r['family'] for r in rows} == set(REQUIRED_FAMILIES), 'ledger family set mismatch')
checks.append('family coverage ledger')
assert_true(all(r['status'] == 'SOURCE_REQUIRED' for r in rows), 'all v1 rows source-required')
checks.append('source-required status')
forb_rows = list(csv.DictReader((ROOT/'ledgers'/'FORBIDDEN_INPUT_LEDGER.csv').open()))
assert_true({r['forbidden_input'] for r in forb_rows} == set(FORBIDDEN_INPUTS), 'forbidden list mismatch')
checks.append('forbidden input list')
valid = json.loads((ROOT/'fixtures'/'valid_empty_transcription_fixture.json').read_text())
cards = load_cards(valid['cards'])
checks.append('valid fixture loads')
try:
    assemble_remainder(cards)
except FormulaValueRequired:
    checks.append('assembler fails closed pending values')
else:
    raise AssertionError('assembler must fail closed')
invalid = json.loads((ROOT/'fixtures'/'invalid_forbidden_transcription_fixture.json').read_text())
try:
    load_cards(invalid['cards'])
except ForbiddenInputError:
    checks.append('forbidden fixture rejected')
else:
    raise AssertionError('forbidden input fixture must reject')
fake = json.loads((ROOT/'fixtures'/'invalid_un_sourced_value_fixture.json').read_text())
try:
    load_cards(fake['cards'])
except FormulaValueRequired:
    checks.append('unsourced value rejected')
else:
    raise AssertionError('unsourced value fixture must reject')
for required in [
    ROOT/'schemas'/'RemainderFamilyValueCard.schema.json',
    ROOT/'schemas'/'RemainderFamilyValueTranscriptionBundle.schema.json',
    ROOT/'theorem'/'OSW_REMAINDER_FAMILY_VALUE_TRANSCRIPTION_BOUNDARY_THEOREM.md',
    ROOT/'paper_drop_in'/'EW_OSW_Remainder_Family_Value_Transcription_DropIn_v1.tex',
]:
    assert_true(required.exists(), f'missing {required}')
checks.append('required artifacts present')
print('EW_OS_W_REMAINDER_FAMILY_VALUE_TRANSCRIPTION_PASS')
print(f'checks={len(checks)}')
print('remainder_families=14')
print('remainder_family_values_transcribed=0')
print('source_required_remainder_family_values=14')
print('exports.value_evaluated=0')
print('hard_stop=source transcription required before numeric assembly')
