
"""Fail-closed OS-W finite-remainder value-transcription boundary."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any

REQUIRED_FAMILIES = ['W_transverse_self_energy', 'Z_transverse_self_energy', 'gamma_Z_mixing', 'gamma_gamma_hadronic_residual', 'vertex_terms', 'box_terms', 'charged_Goldstone_loops', 'neutral_Goldstone_loops', 'ghost_loops', 'gauge_boson_loops', 'Higgs_loops', 'tadpoles', 'mass_charge_weak_angle_counterterms', 'higher_order_QCD_EW_screening']
FORBIDDEN_INPUTS = ['measured_M_W_value', 'DIZET_ZFITTER_aggregate_output', 'published_total_SM_M_W_as_component_value', 'fitted_counterterm', 'post_hoc_tolerance', 'four_over_5063_weak_angle_shortcut', 'measured_sin2theta_eff']

class ForbiddenInputError(ValueError):
    pass

class FormulaValueRequired(RuntimeError):
    pass

@dataclass(frozen=True)
class RemainderFamilyValueCard:
    family: str
    status: str = "source_required"
    source_reference: str | None = None
    equation_locator: str | None = None
    symbol_dictionary: dict[str, Any] | None = None
    renormalization_convention: str | None = None
    finite_part_convention: str | None = None
    coefficient_expression: str | None = None
    numeric_value: float | None = None
    covariance_rule: str | None = None
    target_consumed: bool = False
    forbidden_inputs_used: tuple[str, ...] = ()

    def validate(self) -> None:
        if self.family not in REQUIRED_FAMILIES:
            raise ValueError(f"unknown family: {self.family}")
        bad = set(self.forbidden_inputs_used) & set(FORBIDDEN_INPUTS)
        if bad:
            raise ForbiddenInputError(f"forbidden inputs used: {sorted(bad)}")
        if self.target_consumed:
            raise ForbiddenInputError("target_consumed must be false")
        if self.status not in {"source_required", "source_transcribed"}:
            raise ValueError("invalid status")
        if self.status == "source_required" and self.numeric_value is not None:
            raise FormulaValueRequired("source_required card cannot carry numeric_value")
        if self.status == "source_transcribed":
            missing = [
                name for name, value in [
                    ("source_reference", self.source_reference),
                    ("equation_locator", self.equation_locator),
                    ("coefficient_expression", self.coefficient_expression),
                    ("symbol_dictionary", self.symbol_dictionary),
                    ("renormalization_convention", self.renormalization_convention),
                    ("finite_part_convention", self.finite_part_convention),
                ] if value in (None, "", {})
            ]
            if missing:
                raise FormulaValueRequired(f"source_transcribed card missing {missing}")


def load_cards(raw_cards: list[dict[str, Any]]) -> list[RemainderFamilyValueCard]:
    normalized=[]
    for c in raw_cards:
        c=dict(c)
        if isinstance(c.get('forbidden_inputs_used'), list):
            c['forbidden_inputs_used'] = tuple(c['forbidden_inputs_used'])
        normalized.append(c)
    cards = [RemainderFamilyValueCard(**c) for c in normalized]
    seen = {c.family for c in cards}
    missing = set(REQUIRED_FAMILIES) - seen
    extra = seen - set(REQUIRED_FAMILIES)
    if missing or extra or len(cards) != len(REQUIRED_FAMILIES):
        raise ValueError(f"family coverage failure: missing={sorted(missing)}, extra={sorted(extra)}")
    for card in cards:
        card.validate()
    return cards


def assemble_remainder(cards: list[RemainderFamilyValueCard]) -> float:
    """Fail closed until all finite-remainder family values are source-transcribed."""
    for card in cards:
        card.validate()
    pending = [c.family for c in cards if c.status != "source_transcribed"]
    if pending:
        raise FormulaValueRequired(f"source-certified values required for {len(pending)} families: {pending}")
    if any(c.numeric_value is None for c in cards):
        raise FormulaValueRequired("all transcribed cards must carry numeric_value")
    return sum(float(c.numeric_value) for c in cards)
