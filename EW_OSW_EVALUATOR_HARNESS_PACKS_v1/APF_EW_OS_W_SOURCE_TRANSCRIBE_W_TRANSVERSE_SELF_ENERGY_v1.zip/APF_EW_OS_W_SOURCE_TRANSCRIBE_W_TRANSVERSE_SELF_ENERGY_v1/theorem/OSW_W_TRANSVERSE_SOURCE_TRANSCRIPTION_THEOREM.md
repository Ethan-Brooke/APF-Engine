# OS-W W-transverse source-transcription boundary theorem

Let the one-loop on-shell electroweak correction be assembled as

\[
\Delta r=\Pi'_{\gamma\gamma}(0)+
\frac{\Pi_{WW}^{1PI}(0)-\operatorname{Re}\Pi_{WW}^{1PI}(m_W^2)}{m_W^2}
+\frac{c_W^2}{s_W^2}\left(
\frac{\operatorname{Re}\Pi_{WW}^{1PI}(m_W^2)}{m_W^2}
-\frac{\operatorname{Re}\Pi_{ZZ}^{1PI}(m_Z^2)}{m_Z^2}
\right)
+2\frac{c_W}{s_W}\frac{\Pi^{1PI}_{Z\gamma}(0)}{m_Z^2}+\delta_{VB}.
\]

Then the W-transverse finite-remainder family enters through

\[
\Delta r_W=
\frac{\Pi_{WW}^{1PI}(0)-\operatorname{Re}\Pi_{WW}^{1PI}(m_W^2)}{m_W^2}
+\frac{c_W^2}{s_W^2}
\frac{\operatorname{Re}\Pi_{WW}^{1PI}(m_W^2)}{m_W^2}.
\]

This pack source-transcribes this coefficient map. It does not compute
\(\Pi_{WW}^{1PI}\), does not assemble full \(\Delta r\), and does not export a W-mass value.
