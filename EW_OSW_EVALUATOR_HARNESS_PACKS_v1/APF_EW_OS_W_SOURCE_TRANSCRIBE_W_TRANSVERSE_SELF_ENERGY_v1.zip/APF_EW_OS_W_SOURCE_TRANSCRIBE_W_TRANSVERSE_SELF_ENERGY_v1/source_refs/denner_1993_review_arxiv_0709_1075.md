# Techniques for the calculation of electroweak radiative corrections at the one-loop level and results for W-physics at LEP200

URL: https://arxiv.org/abs/0709.1075

Role: General reviewed source for one-loop EW renormalization, counterterms, scalar integrals, tensor reduction, and W-physics conventions.

Equations used: review scaffold only in this pack

Target consumed: False
