# Tripling down on the W boson mass

URL: https://link.springer.com/article/10.1140/epjc/s10052-022-10934-5

Role: Open-access equation source for OS Delta r assembly, weak-angle counterterm, alpha counterterm, and one-loop Delta r expression.

Equations used: Eq. (15), Eq. (16), Eq. (17), Eq. (18), Eq. (19), Eq. (20)

Target consumed: False
