#!/usr/bin/env python3
from pathlib import Path
import json, csv, math, sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from evaluator_first_family.osw_w_transverse_self_energy import (
    WTransverseInput, evaluate_w_transverse_family, guard_forbidden_inputs, ForbiddenInputError
)

checks = []

def check(name, cond):
    checks.append((name, bool(cond)))

claim = json.loads((ROOT/'CLAIM_LEDGER.json').read_text())
check('contract_export', claim['exports']['Export_OSW_W_transverse_self_energy_source_transcribed'] == 1)
check('value_not_exported', claim['exports']['Export_OSW_APF_internal_delta_r_rem_evaluated'] == 0)
check('MW_not_exported', claim['exports']['Export_numeric_MW_prediction_from_this_pack'] == 0)

cards = list(csv.DictReader((ROOT/'equations'/'W_TRANSVERSE_SOURCE_EQUATION_CARDS.csv').open()))
ids = {r['equation_id'] for r in cards}
check('full_delta_r_card_present', 'OSW_DELTA_R_ONE_LOOP_FULL' in ids)
check('w_slice_card_present', 'OSW_W_TRANSVERSE_FAMILY_SLICE' in ids)
check('w_kernel_card_present', 'OSW_W_TRANSVERSE_COEFFICIENT_KERNEL' in ids)
check('all_cards_target_false', all(r['target_consumed'] == 'False' for r in cards))

fixture = json.loads((ROOT/'fixtures'/'valid_w_transverse_fixture.json').read_text())
guard_forbidden_inputs(fixture)
res = evaluate_w_transverse_family(WTransverseInput(**fixture))
expected = (fixture['Pi_WW_0'] - fixture['RePi_WW_mW2'])/fixture['mW2'] + (fixture['cW2']/fixture['sW2'])*(fixture['RePi_WW_mW2']/fixture['mW2'])
check('kernel_matches_expected', abs(res.delta_r_W - expected) < 1e-15)
check('not_full_delta_r', res.value_is_full_delta_r is False)
check('target_not_consumed', res.target_consumed is False)

bad = json.loads((ROOT/'fixtures'/'invalid_forbidden_input_fixture.json').read_text())
try:
    guard_forbidden_inputs(bad)
    bad_ok = False
except ForbiddenInputError:
    bad_ok = True
check('forbidden_guard_fires', bad_ok)

refs = list(csv.DictReader((ROOT/'source_refs'/'SOURCE_REFERENCE_LEDGER.csv').open()))
check('source_refs_present', len(refs) >= 2)
check('source_targets_false', all(r['target_consumed'] == 'False' for r in refs))

failed = [name for name, ok in checks if not ok]
if failed:
    print('EW_OS_W_SOURCE_TRANSCRIBE_W_TRANSVERSE_SELF_ENERGY_FAIL')
    print('\n'.join(failed))
    sys.exit(1)
print('EW_OS_W_SOURCE_TRANSCRIBE_W_TRANSVERSE_SELF_ENERGY_PASS')
print(f'checks={len(checks)}')
print('family=W_transverse_self_energy')
print('exports.value_evaluated=0')
print('next_gate=APF_EW_OS_W_SOURCE_TRANSCRIBE_Z_TRANSVERSE_OR_GAMMAZ_v1')
