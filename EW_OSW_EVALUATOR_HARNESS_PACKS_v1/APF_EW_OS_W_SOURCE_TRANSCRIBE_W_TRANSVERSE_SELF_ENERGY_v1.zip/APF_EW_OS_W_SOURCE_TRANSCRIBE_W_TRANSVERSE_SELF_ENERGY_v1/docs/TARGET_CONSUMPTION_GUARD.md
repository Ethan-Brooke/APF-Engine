# Target consumption guard

The evaluator rejects inputs containing any forbidden target field:

- measured_M_W_value
- DIZET_ZFITTER_aggregate_output
- published_total_SM_M_W_as_component_value
- fitted_counterterm
- post_hoc_tolerance
- four_over_5063_weak_angle_shortcut
- measured_sin2theta_eff

Audit target windows remain comparators only and are not consumed by the runtime kernel.
