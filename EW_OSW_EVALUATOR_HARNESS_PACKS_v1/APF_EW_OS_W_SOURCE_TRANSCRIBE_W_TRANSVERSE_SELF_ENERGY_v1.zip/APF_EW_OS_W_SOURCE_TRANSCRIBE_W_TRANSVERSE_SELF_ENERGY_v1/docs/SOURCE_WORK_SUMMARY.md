# Source work summary

This pack transcribes the first finite-remainder family from the reviewed on-shell `Delta r` equation: the W transverse self-energy contribution.

The source equation used is the open-access EPJC `Tripling down on the W boson mass` one-loop OS assembly. Its Eq. (18) gives `Delta r` in terms of:

- `Pi'_gamma gamma(0)`,
- `Pi_WW(0)`,
- `Re Pi_WW(m_W^2)`,
- `Re Pi_ZZ(m_Z^2)`,
- `Pi_Z gamma(0)`,
- `delta_VB`.

The W-family slice is exactly the two W terms in Eq. (18). This pack implements only that coefficient map.

## Boundary

The pack does not transcribe the internal diagram-level expression for `Pi_WW`. It defines the slot and coefficient structure into which a later source-certified `Pi_WW` expression must land.
