# Honest non-claims

This pack does not claim:

- evaluated `DeltaRhobarW`,
- evaluated `Delta r_rem`,
- evaluated `Delta r_OS`,
- a numerical W-mass prediction,
- a replacement for DIZET/ZFITTER,
- full one-loop SM electroweak self-energy calculation,
- APF-internal derivation of Denner/Sirlin coefficients,
- fitted counterterms or target-tuned finite parts.

It claims only a source-transcribed coefficient kernel for the first finite-remainder family: `W_transverse_self_energy`.
