# Next source queue

After `W_transverse_self_energy`, the next family should be either:

1. `Z_transverse_self_energy`, because Eq. (18) contains the companion custodial-breaking combination;
2. `gamma_Z_mixing`, because Eq. (17)/(18) exposes the photon--Z mixing contribution directly;
3. `vertex_terms` + `box_terms`, because Eq. (19) gives a compact SM light-lepton approximation for `delta_VB` in the cited source.

Do not assemble a full `Delta r` value until all required families are source-transcribed and the covariance/convention gates pass.
