# APF EW OS-W Source Transcription: W Transverse Self-Energy v1

This pack lands the first finite-remainder-family source transcription for the APF-internal OS-W evaluator route.

**Family transcribed:** `W_transverse_self_energy`.

The pack isolates the coefficient kernel by which the W transverse self-energy appears in the one-loop on-shell `Delta r` expression:

```math
\Delta r_W = rac{\Pi_{WW}^{1PI}(0)-\operatorname{Re}\Pi_{WW}^{1PI}(m_W^2)}{m_W^2}
+ rac{c_W^2}{s_W^2}rac{\operatorname{Re}\Pi_{WW}^{1PI}(m_W^2)}{m_W^2}.
```

Equivalently:

```math
\Delta r_W = rac{\Pi_{WW}^{1PI}(0)}{m_W^2}
+\left(rac{c_W^2}{s_W^2}-1ight)
rac{\operatorname{Re}\Pi_{WW}^{1PI}(m_W^2)}{m_W^2}.
```

This is **not** a full self-energy calculation. It supplies a source-transcribed coefficient-level slot and fail-closed runtime kernel. The actual `Pi_WW` loop function remains a source-required input for the next gate.

## Verifier

```bash
python scripts/check_osw_w_transverse_source_transcription.py
```

Expected output:

```text
EW_OS_W_SOURCE_TRANSCRIBE_W_TRANSVERSE_SELF_ENERGY_PASS
```
