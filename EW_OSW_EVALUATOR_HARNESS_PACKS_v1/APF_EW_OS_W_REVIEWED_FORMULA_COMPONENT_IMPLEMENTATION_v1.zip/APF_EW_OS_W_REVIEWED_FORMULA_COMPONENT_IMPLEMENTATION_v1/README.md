# APF EW OS-W Reviewed Formula Component Implementation v1

This is **Gate 3b** in the OS-W APF-internal electroweak route.

It follows:

1. `APF_EW_OS_W_RENORMALIZED_SELF_ENERGY_EVALUATOR_CONTRACT_v1`
2. `APF_EW_OS_W_DIAGRAM_FAMILY_LEDGER_v1`
3. `APF_EW_OS_W_REVIEWED_FORMULA_EVALUATOR_SCAFFOLD_v1`

This pack implements two isolated analytic component kernels against the scaffold:

```text
DeltaAlpha_leptonic_one_loop_asymptotic
DeltaRho_leading_top_custodial_breaking
```

It **does not** evaluate the OS-W electroweak value, `DeltaRhobarW`, `Delta_r_rem`, or `M_W`.
The full route remains open until the remaining finite one-loop components, counterterms, tadpoles,
Goldstone/ghost/gauge sectors, vertex/box terms, gamma-Z mixing, and higher-order screening ledgers are implemented
and benchmarked under the declared renormalization convention.

## Positive export

```text
Export_OSW_reviewed_formula_component_implementation_partial = 1
```

## Preserved non-claims

```text
Export_OSW_APF_internal_DeltaRhobarW_evaluated = 0
Export_OSW_APF_internal_delta_r_rem_evaluated = 0
Export_OSW_APF_internal_full_loop_derivation = 0
Export_OSW_full_Delta_r_OS_value = 0
Export_numeric_MW_prediction_from_this_pack = 0
Export_DIZET_replacement_evaluator = 0
```

## Verifier

```bash
python scripts/check_osw_component_implementation.py
```

Expected:

```text
EW_OS_W_REVIEWED_FORMULA_COMPONENT_IMPLEMENTATION_PASS
```
