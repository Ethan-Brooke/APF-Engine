#!/usr/bin/env python3
"""Partial OS-W reviewed-formula component kernels.

This module intentionally implements only two component kernels:
- asymptotic one-loop leptonic DeltaAlpha;
- leading heavy-top DeltaRho.

It refuses to evaluate a full OS-W Delta r value until all required components are implemented.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Mapping
import math

FORBIDDEN_INPUTS = {
    "measured_M_W_value",
    "DIZET_ZFITTER_aggregate_output",
    "published_total_SM_M_W_as_component_value",
    "fitted_counterterm",
    "post_hoc_tolerance",
    "four_over_5063_weak_angle_shortcut",
    "measured_sin2theta_eff",
}

class ForbiddenInputError(ValueError):
    """Raised when a forbidden target or aggregate input is present."""

class IncompleteEvaluatorError(RuntimeError):
    """Raised when a caller attempts to use the partial kernels as a full EW evaluator."""

@dataclass(frozen=True)
class EWKernelInputCard:
    alpha0: float
    G_F: float
    M_Z: float
    m_e: float
    m_mu: float
    m_tau: float
    m_t_source: float
    metadata: Mapping[str, Any]

    def validate(self) -> None:
        _assert_no_forbidden_keys(asdict(self))
        for name in ("alpha0", "G_F", "M_Z", "m_e", "m_mu", "m_tau", "m_t_source"):
            val = getattr(self, name)
            if not isinstance(val, (int, float)) or not math.isfinite(float(val)) or float(val) <= 0:
                raise ValueError(f"{name} must be finite and positive")


def _assert_no_forbidden_keys(obj: Any, path: str = "root") -> None:
    if isinstance(obj, Mapping):
        for key, value in obj.items():
            if str(key) in FORBIDDEN_INPUTS:
                raise ForbiddenInputError(f"forbidden input key {key!r} at {path}")
            _assert_no_forbidden_keys(value, f"{path}.{key}")
    elif isinstance(obj, (list, tuple)):
        for idx, value in enumerate(obj):
            _assert_no_forbidden_keys(value, f"{path}[{idx}]")


def delta_alpha_leptonic_one_loop_asymptotic(alpha0: float, q: float, lepton_masses: Mapping[str, float]) -> float:
    """Asymptotic one-loop leptonic running-alpha shell.

    Delta alpha_l(q^2) = sum_l alpha(0)/(3*pi) * [log(q^2/m_l^2) - 5/3].

    Domain: q >> m_l. This is a component kernel, not a full Delta alpha evaluator.
    """
    if alpha0 <= 0 or q <= 0:
        raise ValueError("alpha0 and q must be positive")
    total = 0.0
    for name, mass in lepton_masses.items():
        if mass <= 0:
            raise ValueError(f"lepton mass for {name} must be positive")
        total += (alpha0 / (3.0 * math.pi)) * (math.log((q*q)/(mass*mass)) - 5.0/3.0)
    return total


def delta_rho_leading_top(G_F: float, m_t: float) -> float:
    """Leading heavy-top custodial-breaking rho shell.

    Delta rho_t = 3 G_F m_t^2 / (8 sqrt(2) pi^2).

    This is not the full EW rho and not the bosonic finite remainder.
    """
    if G_F <= 0 or m_t <= 0:
        raise ValueError("G_F and m_t must be positive")
    return (3.0 * G_F * m_t * m_t) / (8.0 * math.sqrt(2.0) * math.pi * math.pi)


def evaluate_partial_components(card: EWKernelInputCard) -> dict[str, Any]:
    """Evaluate only the implemented partial component kernels."""
    card.validate()
    dalpha_l = delta_alpha_leptonic_one_loop_asymptotic(
        card.alpha0,
        card.M_Z,
        {"e": card.m_e, "mu": card.m_mu, "tau": card.m_tau},
    )
    drho_t = delta_rho_leading_top(card.G_F, card.m_t_source)
    return {
        "target_consumed": False,
        "full_value_evaluated": False,
        "implemented_components": {
            "delta_alpha_leptonic_one_loop_asymptotic": dalpha_l,
            "delta_rho_leading_top": drho_t,
        },
        "pending_components": [
            "delta_alpha_hadronic_5",
            "W_self_energy_transverse",
            "Z_self_energy_transverse",
            "gamma_gamma_vacuum_polarization",
            "gamma_Z_mixing",
            "vertex_leptonic_muon_decay",
            "box_muon_decay",
            "charged_Goldstone_loops",
            "neutral_Goldstone_loops",
            "ghost_loops",
            "gauge_boson_loops",
            "Higgs_loops",
            "tadpole_convention_block",
            "mass_charge_weak_angle_counterterms",
            "higher_order_QCD_EW_screening",
        ],
        "non_claim": "partial component kernels only; no OS-W value exported",
    }


def evaluate_delta_r_os_full(*args: Any, **kwargs: Any) -> dict[str, Any]:
    """Fail closed until every required component is implemented."""
    raise IncompleteEvaluatorError(
        "Full OS-W Delta r evaluation is not implemented in this pack; component kernels are partial."
    )
