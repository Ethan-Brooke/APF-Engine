# No-smuggling ledger

Forbidden inputs remain:

```text
measured_M_W_value
DIZET_ZFITTER_aggregate_output
published_total_SM_M_W_as_component_value
fitted_counterterm
post_hoc_tolerance
four_over_5063_weak_angle_shortcut
measured_sin2theta_eff
```

The runtime guard rejects any input-card or formula-registry field containing these keys.

The frozen target intervals remain audit comparators only:

```text
DeltaRhobarW(MZ) in [-1.260, -1.136]
Delta_r_rem^alpha in [0.003518, 0.003839]
Delta_r_rem_target in [0.009409, 0.009730]
```
