# Implemented component kernels

This pack implements only two component kernels. They are insufficient for an OS-W value.

## 1. Leptonic running-alpha component

For a high-scale timelike input `q` with `q >> m_l`, the implemented asymptotic one-loop shell is

\[
\Delta\alpha_\ell(q^2)
=
\sum_{\ell=e,\mu,\tau}
\frac{\alpha(0)}{3\pi}
\left[
\log\left(\frac{q^2}{m_\ell^2}\right)-\frac{5}{3}
\right].
\]

Status: `implemented_component_kernel`, not full reviewed-evaluator closure. The source citation/equation pointer remains a required
ledger field before publication-grade formula import.

## 2. Leading top custodial-breaking rho component

The implemented leading heavy-top custodial-breaking shell is

\[
\Delta\rho_t^{\rm lead}
=
\frac{3G_F m_t^2}{8\sqrt{2}\pi^2}.
\]

Status: `implemented_component_kernel`, not full EW rho. It omits bottom finite terms, bosonic pieces, QCD screening,
EW two-loop corrections, gauge-sector finite parts, and scheme-dependent counterterm assembly.

## Why this matters

The previous diagnostic scalar failed because it did not carry a renormalized EW convention. This pack begins the opposite route:
small components are implemented only when their domain, approximation, forbidden-input guard, and non-claim status are explicit.

## Why this does not evaluate OS-W

The OS decomposition is

\[
\Delta r_{\rm OS}
=
\Delta\alpha
-
\frac{c_W^2}{s_W^2}\Delta\rho
+
\Delta r_{\rm rem}.
\]

The current pack contributes two isolated pieces. The remainder term, full counterterm structure, gauge cancellations,
and finite self-energy convention are still absent. Therefore no electroweak value is exported.
