# Honest non-claims

This pack does not claim:

```text
Export_OSW_APF_internal_DeltaRhobarW_evaluated = 0
Export_OSW_APF_internal_delta_r_rem_evaluated = 0
Export_OSW_APF_internal_full_loop_derivation = 0
Export_OSW_full_reviewed_formula_evaluator = 0
Export_OSW_full_Delta_r_OS_value = 0
Export_numeric_MW_prediction_from_this_pack = 0
Export_DIZET_replacement_evaluator = 0
Export_measured_MW_reproduction = 0
Export_measured_sin2theta_eff_reproduction = 0
```

The implemented kernels are component-level shells. They are not a replacement for DIZET/ZFITTER, not a full on-shell
renormalized electroweak calculation, and not a value-producing W-mass route.
