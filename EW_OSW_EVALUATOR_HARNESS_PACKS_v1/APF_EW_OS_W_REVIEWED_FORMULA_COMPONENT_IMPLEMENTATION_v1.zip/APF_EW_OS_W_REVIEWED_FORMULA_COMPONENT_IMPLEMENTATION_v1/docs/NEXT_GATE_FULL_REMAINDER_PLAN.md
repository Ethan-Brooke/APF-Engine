# Next gate: full remainder component implementation

The next gate is not another scalar diagnostic. It is term-by-term implementation of the remaining finite components.

Priority order:

1. photon vacuum polarization and hadronic DeltaAlpha ledger/covariance import;
2. gamma-Z mixing term and counterterm linkage;
3. W/Z transverse self-energy finite parts under the declared OS convention;
4. vertex and box corrections for muon decay;
5. Goldstone + ghost + gauge-boson cancellation blocks;
6. Higgs and tadpole convention blocks;
7. mass, charge, weak-angle, and field-renormalization counterterms;
8. higher-order QCD/EW screening uncertainty ledger.

Only after these are populated and benchmarked may the route attempt:

```text
Export_OSW_APF_internal_delta_r_rem_evaluated = 1
```
