# OS-W partial component implementation theorem

## Theorem

Let an OS-W electroweak evaluator be required to compute

\[
\Delta r_{\rm OS}=\Delta\alpha-\frac{c_W^2}{s_W^2}\Delta\rho+\Delta r_{\rm rem}.
\]

A partial component implementation may be promoted only as a component-kernel artifact if:

1. every implemented component declares its formula domain and approximation class;
2. the component carries no forbidden target input;
3. the component status ledger distinguishes implemented kernels from pending finite parts;
4. full-value evaluation fails closed until all required components are present;
5. exported claims remain component-level.

## Consequence

When these conditions hold,

\[
\operatorname{Export}_{\rm component\;kernel}=1.
\]

They do not imply

\[
\operatorname{Export}_{\rm OSW\;value}=1.
\]

The APF-internal OS-W route remains bounded until a complete renormalized finite-part evaluator exists.
