#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from evaluator_components.osw_component_kernels import (
    EWKernelInputCard,
    ForbiddenInputError,
    IncompleteEvaluatorError,
    evaluate_partial_components,
    evaluate_delta_r_os_full,
)

REQUIRED_FILES = [
    "README.md",
    "CLAIM_LEDGER.json",
    "results/CLOSURE_STATEMENT.json",
    "docs/IMPLEMENTED_COMPONENTS.md",
    "docs/NO_SMUGGLING_LEDGER.md",
    "docs/HONEST_NON_CLAIMS.md",
    "tables/component_implementation_status.csv",
    "ledgers/FORBIDDEN_INPUT_LEDGER.csv",
    "evaluator_components/osw_component_kernels.py",
    "fixtures/valid_component_kernel_fixture.json",
    "fixtures/invalid_forbidden_input_fixture.json",
    "theorem/OSW_COMPONENT_IMPLEMENTATION_PARTIAL_THEOREM.md",
]

EXPECTED_FORBIDDEN = {
    "measured_M_W_value",
    "DIZET_ZFITTER_aggregate_output",
    "published_total_SM_M_W_as_component_value",
    "fitted_counterterm",
    "post_hoc_tolerance",
    "four_over_5063_weak_angle_shortcut",
    "measured_sin2theta_eff",
}

EXPECTED_IMPLEMENTED = {
    "delta_alpha_leptonic_one_loop_asymptotic",
    "delta_rho_leading_top",
}

FORBIDDEN_VALUE_EXPORTS = [
    "Export_OSW_APF_internal_DeltaRhobarW_evaluated",
    "Export_OSW_APF_internal_delta_r_rem_evaluated",
    "Export_OSW_APF_internal_full_loop_derivation",
    "Export_OSW_full_reviewed_formula_evaluator",
    "Export_OSW_full_Delta_r_OS_value",
    "Export_numeric_MW_prediction_from_this_pack",
    "Export_DIZET_replacement_evaluator",
    "Export_fitted_counterterm",
]

def fail(msg: str) -> None:
    print(f"FAIL: {msg}")
    sys.exit(1)

def main() -> None:
    for rel in REQUIRED_FILES:
        if not (ROOT / rel).exists():
            fail(f"missing required file {rel}")

    closure = json.loads((ROOT / "results/CLOSURE_STATEMENT.json").read_text())
    exports = closure["exports"]
    if exports.get("Export_OSW_reviewed_formula_component_implementation_partial") != 1:
        fail("partial component implementation export not set")
    for key in FORBIDDEN_VALUE_EXPORTS:
        if exports.get(key) != 0:
            fail(f"forbidden value-level export {key} must remain 0")
    if closure.get("target_consumed") is not False:
        fail("target_consumed must be false")
    if closure.get("full_value_evaluated") is not False:
        fail("full_value_evaluated must be false")

    with (ROOT / "tables/component_implementation_status.csv").open() as f:
        rows = list(csv.DictReader(f))
    implemented = {r["component_id"] for r in rows if r["implemented_in_v1"] == "1"}
    if implemented != EXPECTED_IMPLEMENTED:
        fail(f"implemented component set mismatch: {implemented}")
    if len(rows) < 16:
        fail("component ledger too small")

    with (ROOT / "ledgers/FORBIDDEN_INPUT_LEDGER.csv").open() as f:
        forbidden = {r["input"] for r in csv.DictReader(f)}
    if forbidden != EXPECTED_FORBIDDEN:
        fail(f"forbidden ledger mismatch: {forbidden}")

    fixture = json.loads((ROOT / "fixtures/valid_component_kernel_fixture.json").read_text())
    card = EWKernelInputCard(**fixture)
    result = evaluate_partial_components(card)
    if result["target_consumed"] is not False or result["full_value_evaluated"] is not False:
        fail("partial evaluator target/full flags incorrect")
    comps = result["implemented_components"]
    # Broad smoke ranges only; these are not target comparisons.
    if not (0.02 < comps["delta_alpha_leptonic_one_loop_asymptotic"] < 0.04):
        fail("leptonic DeltaAlpha smoke value outside broad range")
    if not (0.005 < comps["delta_rho_leading_top"] < 0.02):
        fail("leading top DeltaRho smoke value outside broad range")

    bad = json.loads((ROOT / "fixtures/invalid_forbidden_input_fixture.json").read_text())
    try:
        evaluate_partial_components(EWKernelInputCard(**bad))
        fail("forbidden input fixture did not fail")
    except ForbiddenInputError:
        pass

    try:
        evaluate_delta_r_os_full()
        fail("full evaluator did not fail closed")
    except IncompleteEvaluatorError:
        pass

    print("EW_OS_W_REVIEWED_FORMULA_COMPONENT_IMPLEMENTATION_PASS")
    print(f"implemented_components={len(implemented)}")
    print(f"pending_components={len(rows)-len(implemented)}")
    print(f"forbidden_inputs={len(forbidden)}")
    print("exports.value_evaluated=0")
    print("next_gate=APF_EW_OS_W_REMAINDER_COMPONENT_IMPLEMENTATION_v1")

if __name__ == "__main__":
    main()
