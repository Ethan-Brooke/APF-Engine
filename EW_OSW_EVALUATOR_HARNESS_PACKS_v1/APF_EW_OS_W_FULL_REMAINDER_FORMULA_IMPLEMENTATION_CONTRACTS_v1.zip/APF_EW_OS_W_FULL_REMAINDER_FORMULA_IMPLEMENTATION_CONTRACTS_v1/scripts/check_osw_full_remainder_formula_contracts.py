#!/usr/bin/env python3
from pathlib import Path
import csv, json, importlib.util, sys
ROOT = Path(__file__).resolve().parents[1]
errors=[]
claim=json.loads((ROOT/'CLAIM_LEDGER.json').read_text())
if claim['exports']['Export_OSW_full_remainder_formula_contracts'] != 1: errors.append('contract export not set')
if claim['exports']['Export_OSW_APF_internal_delta_r_rem_evaluated'] != 0: errors.append('value export must stay zero')
rows=list(csv.DictReader((ROOT/'tables'/'FORMULA_FAMILY_CONTRACTS.csv').open()))
if len(rows)!=14: errors.append(f'expected 14 formula family contracts, got {len(rows)}')
forbidden=list(csv.DictReader((ROOT/'ledgers'/'FORBIDDEN_INPUT_LEDGER.csv').open()))
if len(forbidden)!=7: errors.append(f'expected 7 forbidden inputs, got {len(forbidden)}')
# import module
spec=importlib.util.spec_from_file_location('contracts', ROOT/'evaluator_contracts'/'osw_full_remainder_formula_contracts.py')
mod=importlib.util.module_from_spec(spec); sys.modules[spec.name]=mod; spec.loader.exec_module(mod)
summary=mod.contract_summary()
if summary['family_count'] != 14: errors.append('module family count mismatch')
if summary['evaluated'] is not False or summary['target_consumed'] is not False: errors.append('summary must remain unevaluated/no target')
try:
    mod.evaluate_full_remainder(json.loads((ROOT/'fixtures'/'invalid_forbidden_input_fixture.json').read_text()))
    errors.append('forbidden input did not raise')
except mod.ForbiddenInputError:
    pass
except Exception as e:
    errors.append(f'wrong forbidden exception: {e!r}')
try:
    mod.evaluate_full_remainder(json.loads((ROOT/'fixtures'/'valid_formula_contract_fixture.json').read_text()))
    errors.append('valid fixture should fail closed until formula coefficients land')
except mod.FormulaImplementationRequired:
    pass
except Exception as e:
    errors.append(f'wrong fail-closed exception: {e!r}')
# required docs
for p in ['docs/NO_SMUGGLING_LEDGER.md','docs/COUNTERTERM_ASSEMBLY_SPEC.md','docs/GAUGE_CANCELLATION_AND_WARD_GATES.md']:
    if not (ROOT/p).exists(): errors.append(f'missing {p}')
if errors:
    print('EW_OS_W_FULL_REMAINDER_FORMULA_CONTRACTS_FAIL')
    for e in errors: print(' -', e)
    sys.exit(1)
print('EW_OS_W_FULL_REMAINDER_FORMULA_CONTRACTS_PASS')
print('formula_family_contracts=14')
print('forbidden_inputs=7')
print('exports.value_evaluated=0')
print('next_gate=APF_EW_OS_W_REVIEWED_FORMULA_COEFFICIENT_LANDING_v1')
