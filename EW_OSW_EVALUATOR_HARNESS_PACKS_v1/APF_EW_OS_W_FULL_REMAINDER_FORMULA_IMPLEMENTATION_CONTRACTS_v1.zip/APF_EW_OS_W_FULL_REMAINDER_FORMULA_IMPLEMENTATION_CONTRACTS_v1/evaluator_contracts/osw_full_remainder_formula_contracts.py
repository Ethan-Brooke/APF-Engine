
"""Fail-closed OS-W full finite-remainder formula-family contracts.

This module declares the component families required for a future reviewed-formula
implementation of the OS-W finite remainder. It does not evaluate electroweak values.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Any

FORBIDDEN_INPUTS = {
    'measured_M_W_value',
    'DIZET_ZFITTER_aggregate_output',
    'published_total_SM_M_W_as_component_value',
    'fitted_counterterm',
    'post_hoc_tolerance',
    'four_over_5063_weak_angle_shortcut',
    'measured_sin2theta_eff',
}

@dataclass(frozen=True)
class FormulaFamilyContract:
    family: str
    role: str
    status: str
    external_required: bool = False

FAMILIES: List[FormulaFamilyContract] = [
    FormulaFamilyContract('W_transverse_self_energy','Delta_r_rem','contract_declared_formula_pending'),
    FormulaFamilyContract('Z_transverse_self_energy','Delta_r_rem','contract_declared_formula_pending'),
    FormulaFamilyContract('gamma_Z_mixing','Delta_r_rem','contract_declared_formula_pending'),
    FormulaFamilyContract('gamma_gamma_hadronic_residual','Delta_alpha/residual','contract_declared_external_required', True),
    FormulaFamilyContract('vertex_terms','Delta_r_rem','contract_declared_formula_pending'),
    FormulaFamilyContract('box_terms','Delta_r_rem','contract_declared_formula_pending'),
    FormulaFamilyContract('charged_Goldstone_loops','gauge_cancellation','contract_declared_formula_pending'),
    FormulaFamilyContract('neutral_Goldstone_loops','gauge_cancellation','contract_declared_formula_pending'),
    FormulaFamilyContract('ghost_loops','gauge_cancellation','contract_declared_formula_pending'),
    FormulaFamilyContract('gauge_boson_loops','gauge_cancellation','contract_declared_formula_pending'),
    FormulaFamilyContract('Higgs_loops','Higgs/tadpole block','contract_declared_formula_pending'),
    FormulaFamilyContract('tadpoles','counterterm convention','contract_declared_formula_pending'),
    FormulaFamilyContract('mass_charge_weak_angle_counterterms','renormalized assembly','contract_declared_formula_pending'),
    FormulaFamilyContract('higher_order_QCD_EW_screening','truncation covariance','contract_declared_external_required', True),
]

class ForbiddenInputError(ValueError):
    pass

class FormulaImplementationRequired(RuntimeError):
    pass

def assert_no_forbidden_inputs(input_card: Dict[str, Any]) -> None:
    bad = sorted(FORBIDDEN_INPUTS.intersection(input_card.keys()))
    if bad:
        raise ForbiddenInputError(f"Forbidden OS-W evaluator inputs present: {bad}")

def contract_summary() -> Dict[str, Any]:
    return {
        'family_count': len(FAMILIES),
        'external_required_count': sum(1 for f in FAMILIES if f.external_required),
        'all_statuses': sorted({f.status for f in FAMILIES}),
        'evaluated': False,
        'target_consumed': False,
    }

def evaluate_full_remainder(input_card: Dict[str, Any]) -> Dict[str, Any]:
    """Fail closed until reviewed formula coefficients have landed."""
    assert_no_forbidden_inputs(input_card)
    missing = [f.family for f in FAMILIES if 'pending' in f.status or 'external_required' in f.status]
    raise FormulaImplementationRequired(
        'Reviewed formula coefficients/external residual ledgers required before evaluation: ' + ', '.join(missing)
    )
