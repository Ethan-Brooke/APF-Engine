# OS-W Full Remainder Formula Contract Theorem

Let the OS decomposition be

```math
\Delta r_{m OS}=\Deltalpha-rac{c_W^2}{s_W^2}\Deltaho+\Delta r_{m rem}.
```

A source-certified APF-internal OS-W evaluator may be promoted only if every diagram family entering `Delta_r_rem` is represented by a reviewed finite formula or an explicitly declared external residual ledger, and if the counterterm/tadpole/gauge-cancellation conventions are declared before comparison to the frozen target intervals.

This pack declares the complete family-level contract and the fail-closed assembly graph. It does not evaluate the physical value.

Therefore:

```text
Export_OSW_full_remainder_formula_contracts = 1
Export_OSW_APF_internal_delta_r_rem_evaluated = 0
```
