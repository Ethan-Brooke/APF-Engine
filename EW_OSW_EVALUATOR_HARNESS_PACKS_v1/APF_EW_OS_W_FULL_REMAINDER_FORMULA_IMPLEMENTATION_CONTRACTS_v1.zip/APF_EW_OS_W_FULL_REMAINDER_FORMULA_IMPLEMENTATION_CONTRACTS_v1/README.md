# APF EW OS-W Full Remainder Formula Implementation Contracts v1

This pack advances the OS-W APF-internal electroweak route from a finite-PV substrate and fail-closed assembler to a complete **formula-family contract** for the finite electroweak remainder.

It does **not** evaluate `DeltaRhobarW`, `Delta_r_rem`, `Delta_r_OS`, or `M_W`. It deliberately fails closed until reviewed formula coefficients are landed component-by-component.

## Export posture

Positive:

- `Export_OSW_full_remainder_formula_contracts = 1`
- `Export_OSW_component_formula_family_DAG = 1`
- `Export_OSW_counterterm_assembly_spec = 1`
- `Export_OSW_gauge_cancellation_gate_spec = 1`
- `Export_OSW_forbidden_input_guard_preserved = 1`

Preserved non-claims:

- `Export_OSW_APF_internal_DeltaRhobarW_evaluated = 0`
- `Export_OSW_APF_internal_delta_r_rem_evaluated = 0`
- `Export_OSW_full_reviewed_formula_evaluator = 0`
- `Export_numeric_MW_prediction_from_this_pack = 0`

## Why this pack exists

The current APF boundary says the imported OS-W route is preserved while the APF-internal route is bounded until a source-certified renormalized EW self-energy evaluator exists. This pack supplies the next audit surface: a complete formula-family ledger and assembly contract for the finite remainder.
