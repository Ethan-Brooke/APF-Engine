# No-Smuggling Ledger

- `measured_M_W_value` is forbidden.
- `DIZET_ZFITTER_aggregate_output` is forbidden.
- `published_total_SM_M_W_as_component_value` is forbidden.
- `fitted_counterterm` is forbidden.
- `post_hoc_tolerance` is forbidden.
- `four_over_5063_weak_angle_shortcut` is forbidden.
- `measured_sin2theta_eff` is forbidden.

The target intervals may appear only in benchmark tables marked audit-only.
