# Evaluator Boundary

This pack is a formula-family contract, not a numerical evaluator.

The evaluator must remain fail-closed until every required family has reviewed coefficients, a finite-part convention, a scale convention, a gauge/tadpole convention, and a counterterm assembly trace.

The frozen target intervals are audit comparators only. They are forbidden as inputs to coefficient selection or tolerance tuning.
