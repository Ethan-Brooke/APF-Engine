# Full Remainder Formula Contracts

The finite electroweak remainder is decomposed into diagram families and counterterm assemblies. Each family must land with: reviewed formula source, finite part, scale, mass inputs, gauge convention, covariance contribution, forbidden-input declaration, and validation gates.

The contracts are complete when every family in `tables/FORMULA_FAMILY_CONTRACTS.csv` is represented in the component DAG and schema. They are implemented only when status changes from `contract_declared_*` to `formula_implemented_reviewed`.
