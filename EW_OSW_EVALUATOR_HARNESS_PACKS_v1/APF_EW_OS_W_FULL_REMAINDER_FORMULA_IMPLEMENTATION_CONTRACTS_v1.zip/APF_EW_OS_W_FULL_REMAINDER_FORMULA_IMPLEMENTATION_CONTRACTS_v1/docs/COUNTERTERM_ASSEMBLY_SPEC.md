# Counterterm Assembly Spec

The OS decomposition is:

```text
Delta r_OS = Delta alpha - (c_W^2/s_W^2) Delta rho + Delta r_rem
```

A future assembler must report mass counterterms, charge counterterm, weak-angle counterterm, field renormalization pieces where applicable, and residual finite pieces.

This pack declares the assembly map but does not supply reviewed coefficients.
