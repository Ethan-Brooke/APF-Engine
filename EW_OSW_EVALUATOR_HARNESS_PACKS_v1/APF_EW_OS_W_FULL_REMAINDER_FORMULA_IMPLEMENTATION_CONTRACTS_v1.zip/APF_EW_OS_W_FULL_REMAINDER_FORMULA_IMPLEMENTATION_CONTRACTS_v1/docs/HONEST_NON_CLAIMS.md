# Honest Non-Claims

This pack does not compute or predict `M_W`.

It does not replace DIZET/ZFITTER.

It does not implement a full reviewed formula evaluator.

It does not evaluate `DeltaRhobarW`, `Delta_r_rem`, or `Delta_r_OS`.

It does not fit counterterms or tune finite parts to frozen target intervals.
