# Gauge Cancellation and Ward/ST Gates

A future numerical evaluator must pass cancellation tests across gauge boson, Goldstone, ghost, tadpole, and counterterm sectors.

Minimum gates:

1. Transversality / Ward identity checks for photon-sector pieces.
2. Slavnov-Taylor compatibility for gauge-Goldstone-ghost blocks.
3. Tadpole-convention consistency across mass counterterms.
4. Cancellation of unphysical gauge-parameter dependence in the assembled observable.
5. Target-independent validation against reviewed benchmark tables.
