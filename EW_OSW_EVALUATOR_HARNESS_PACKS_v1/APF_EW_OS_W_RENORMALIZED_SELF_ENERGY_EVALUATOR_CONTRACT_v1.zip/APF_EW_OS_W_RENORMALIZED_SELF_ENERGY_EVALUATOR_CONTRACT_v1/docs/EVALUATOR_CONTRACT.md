# Evaluator Contract

The future evaluator is a route-local on-shell electroweak self-energy evaluator for the OS-W route. It must produce a declared decomposition of

\[
\Delta r_{\rm OS}
= \Delta\alpha
- \frac{c_W^2}{s_W^2}\Delta\rho
+ \Delta r_{\rm rem}.
\]

The evaluator must return the ingredients, their covariance, the diagram families used to compute them, and the counterterm/matching conventions.

## Interface

```python
evaluate_delta_r_os(
    input_card: EWInputCard,
    scheme_card: RenormalizationSchemeCard,
    diagram_ledger: DiagramFamilyLedger,
) -> DeltaRResult
```

## Required output fields

```text
Delta_alpha
Delta_rho
Delta_r_rem
Delta_r_total
DeltaRhobarW
finite_part_ledger
renormalization_scale_ledger
subtraction_prescription
counterterm_ledger
tadpole_convention
diagram_family_contributions
covariance_matrix
gauge_parameter_check
Ward_identity_check
target_consumed = False
forbidden_inputs_consumed = []
```

## Gate status

This pack closes only the evaluator contract. It does not instantiate the evaluated value.
