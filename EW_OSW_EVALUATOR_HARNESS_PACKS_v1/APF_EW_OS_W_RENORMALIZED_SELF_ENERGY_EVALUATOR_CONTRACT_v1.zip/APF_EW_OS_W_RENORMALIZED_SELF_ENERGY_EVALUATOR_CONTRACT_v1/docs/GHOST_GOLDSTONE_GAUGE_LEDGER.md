# Ghost / Goldstone / Gauge-Boson Ledger

The diagnostic scalar-B0 helper was refused because it did not carry full EW diagram content. A valid evaluator must include or explicitly justify absence of:

- Transverse gauge-boson self-energy pieces.
- Longitudinal gauge-boson pieces in the declared gauge.
- Goldstone loops.
- Ghost loops.
- Gamma-Z mixing.
- Gauge-restoring terms.
- Gauge-parameter cancellation checks.

A scalar that reports only a bosonic diagonal approximation is not sufficient for APF-internal promotion.
