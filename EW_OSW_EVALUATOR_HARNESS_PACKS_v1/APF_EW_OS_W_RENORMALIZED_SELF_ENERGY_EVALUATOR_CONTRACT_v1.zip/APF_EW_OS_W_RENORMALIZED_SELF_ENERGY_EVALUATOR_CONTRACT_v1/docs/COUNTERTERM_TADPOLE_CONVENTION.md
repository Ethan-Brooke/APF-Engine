# Counterterm and Tadpole Convention

A valid evaluator must declare the counterterm basis and tadpole treatment.

Required counterterms:

- W mass counterterm.
- Z mass counterterm.
- Weak-angle counterterm.
- Electric-charge counterterm.
- Field-renormalization constants needed by the chosen decomposition.
- Vertex and box counterterm relations when used in `Delta r_rem`.

Tadpoles must be handled in one of the declared reviewed conventions and must be included consistently in mass counterterms and gauge-cancellation checks.

The evaluator must not choose a tadpole convention post hoc to hit the APF target interval.
