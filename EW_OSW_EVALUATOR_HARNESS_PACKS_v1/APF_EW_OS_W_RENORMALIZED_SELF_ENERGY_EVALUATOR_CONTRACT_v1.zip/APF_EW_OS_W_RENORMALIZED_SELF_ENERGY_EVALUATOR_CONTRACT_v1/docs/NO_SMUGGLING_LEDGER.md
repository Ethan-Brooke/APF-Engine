# No-Smuggling Ledger

Forbidden inputs:

```text
measured_M_W_value
DIZET_ZFITTER_aggregate_output
published_total_SM_M_W_as_component_value
fitted_counterterm
post_hoc_tolerance
four_over_5063_weak_angle_shortcut
measured_sin2theta_eff
```

Allowed uses:

- The frozen target intervals may be used only as audit comparators.
- Reviewed formulae may be imported only with provenance and their component role named.
- External constants may be used only through the declared external ledger.
- DIZET/ZFITTER may be used only as external comparison or imported-route provenance, not as an APF-internal evaluated component.
