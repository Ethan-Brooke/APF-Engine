# Benchmark Targets

This contract preserves three target surfaces.

## Current-depth boundary target

```text
DeltaRhobarW(MZ) in [-1.260, -1.136]
Delta_r_rem_alpha in [0.003518, 0.003839]
```

## Required OS remainder window

```text
Delta_r_rem_target in [0.009409, 0.009730]
midpoint = 0.009569
```

## Diagnostic nonpromotion

```text
DeltaRhobarW_bos_diag = 2.485
promoted = false
```

These are audit targets, not fitted values. A future evaluator must compute its values from declared diagram content.
