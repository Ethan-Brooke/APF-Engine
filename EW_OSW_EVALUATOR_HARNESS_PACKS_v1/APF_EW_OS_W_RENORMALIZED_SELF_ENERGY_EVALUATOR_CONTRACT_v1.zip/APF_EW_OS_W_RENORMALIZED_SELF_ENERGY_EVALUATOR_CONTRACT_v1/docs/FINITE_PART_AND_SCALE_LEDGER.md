# Finite-Part and Scale Ledger

A valid evaluator must declare:

1. The loop-regularization scheme.
2. The finite-part convention for scalar integrals.
3. The renormalization scale or explicit scale-independence statement.
4. Which logarithms are carried in the finite part.
5. How same-input comparisons are made across diagram families.
6. How covariance from external constants and numerical integration is propagated.

No finite counterterm may be fitted to the OS-W target interval. The target interval is an audit comparator only.
