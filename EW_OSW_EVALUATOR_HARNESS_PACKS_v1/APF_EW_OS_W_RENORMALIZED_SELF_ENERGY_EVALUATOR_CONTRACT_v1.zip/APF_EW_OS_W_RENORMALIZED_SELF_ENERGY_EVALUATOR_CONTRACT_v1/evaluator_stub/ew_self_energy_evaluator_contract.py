"""APF OS-W renormalized EW self-energy evaluator contract.

This module is a contract stub. It intentionally does not evaluate an EW value.
"""
from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass(frozen=True)
class EWInputCard:
    alpha_0: float
    G_F: float
    M_Z: float
    M_W_trace: float
    external_ledger: List[Dict[str, Any]]
    target_value_consumed: bool = False


@dataclass(frozen=True)
class RenormalizationSchemeCard:
    scheme: str
    finite_part_convention: str
    renormalization_scale_convention: str
    subtraction_prescription: str
    tadpole_convention: str
    counterterm_matching_scheme: str
    covariance_protocol: str


@dataclass(frozen=True)
class DiagramFamilyLedger:
    families: List[Dict[str, Any]]
    coverage_complete: bool


@dataclass(frozen=True)
class DeltaRResult:
    Delta_alpha: float
    Delta_rho: float
    Delta_r_rem: float
    Delta_r_total: float
    target_consumed: bool
    forbidden_inputs_consumed: List[str]
    covariance_matrix: List[List[float]]
    Ward_identity_check: bool
    gauge_parameter_check: bool
    finite_part_ledger: Dict[str, Any] = field(default_factory=dict)
    counterterm_ledger: Dict[str, Any] = field(default_factory=dict)


def validate_contract_inputs(input_card: EWInputCard, scheme_card: RenormalizationSchemeCard, diagram_ledger: DiagramFamilyLedger) -> None:
    if input_card.target_value_consumed:
        raise ValueError("target value consumed by evaluator input card")
    if scheme_card.scheme != "on_shell":
        raise ValueError("contract v1 requires on_shell scheme")
    required_fields = [
        scheme_card.finite_part_convention,
        scheme_card.renormalization_scale_convention,
        scheme_card.subtraction_prescription,
        scheme_card.tadpole_convention,
        scheme_card.counterterm_matching_scheme,
        scheme_card.covariance_protocol,
    ]
    if any(not str(x).strip() for x in required_fields):
        raise ValueError("missing required renormalization convention")
    if not diagram_ledger.coverage_complete:
        raise ValueError("diagram family ledger is incomplete")


def evaluate_delta_r_os(input_card: EWInputCard, scheme_card: RenormalizationSchemeCard, diagram_ledger: DiagramFamilyLedger) -> DeltaRResult:
    """Future evaluator entry point.

    This contract pack intentionally refuses to implement numerical evaluation.
    """
    validate_contract_inputs(input_card, scheme_card, diagram_ledger)
    raise NotImplementedError("contract only: APF-internal Delta r evaluator is not implemented in v1")
