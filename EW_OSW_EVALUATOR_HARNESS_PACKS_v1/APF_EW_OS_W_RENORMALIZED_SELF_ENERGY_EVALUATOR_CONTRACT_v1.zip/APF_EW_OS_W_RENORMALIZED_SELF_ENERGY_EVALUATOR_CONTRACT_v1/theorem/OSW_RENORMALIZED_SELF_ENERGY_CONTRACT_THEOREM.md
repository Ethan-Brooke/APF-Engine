# OS-W Renormalized Self-Energy Evaluator Contract Theorem

Let an OS-W APF-internal evaluator claim to compute

\[
\Delta r_{\rm OS}
= \Delta\alpha
-\frac{c_W^2}{s_W^2}\Delta\rho
+\Delta r_{\rm rem}.
\]

Such an evaluator is promotable only if it declares:

1. on-shell renormalization scheme;
2. finite-part convention;
3. renormalization scale convention;
4. subtraction prescription;
5. Goldstone/ghost/gauge-boson diagram-class content;
6. tadpole convention;
7. fermionic pieces;
8. counterterm/matching scheme;
9. covariance protocol;
10. no-smuggling ledger.

If any required convention is absent, the output is a diagnostic scalar or external comparator, not an APF-internal evaluated route component.

This pack proves only that the required contract is specified and machine-checkable.
