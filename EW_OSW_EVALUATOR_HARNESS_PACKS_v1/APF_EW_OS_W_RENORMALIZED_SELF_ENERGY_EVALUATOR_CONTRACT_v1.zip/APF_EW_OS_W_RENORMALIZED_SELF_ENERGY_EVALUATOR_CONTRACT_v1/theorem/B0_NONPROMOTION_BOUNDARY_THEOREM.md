# Diagnostic Scalar-B0 Nonpromotion Boundary

The current-depth diagnostic scalar-B0 helper returns

\[
\overline{\Delta\rho}^{\rm bos,diag}_W = 2.485,
\]

while the frozen target interval is

\[
\overline{\Delta\rho}_W(M_Z) \in [-1.260,-1.136].
\]

Because this helper lacks the full renormalized self-energy convention, it is not promoted as an APF-internal component. Its failure is a boundary closure, not a structural no-go against a future source-certified evaluator.
