#!/usr/bin/env python3
from pathlib import Path
import json, csv, sys

ROOT = Path(__file__).resolve().parents[1]

REQUIRED_FILES = [
    "README.md",
    "CLAIM_LEDGER.json",
    "docs/EVALUATOR_CONTRACT.md",
    "docs/RENORMALIZATION_SCHEME_CARD.json",
    "docs/FINITE_PART_AND_SCALE_LEDGER.md",
    "docs/COUNTERTERM_TADPOLE_CONVENTION.md",
    "docs/GHOST_GOLDSTONE_GAUGE_LEDGER.md",
    "docs/NO_SMUGGLING_LEDGER.md",
    "docs/BENCHMARK_TARGETS.md",
    "docs/HONEST_NON_CLAIMS.md",
    "docs/INTEGRATOR_NOTE.md",
    "theorem/OSW_RENORMALIZED_SELF_ENERGY_CONTRACT_THEOREM.md",
    "theorem/B0_NONPROMOTION_BOUNDARY_THEOREM.md",
    "tables/diagram_family_ledger.csv",
    "tables/benchmark_targets.csv",
    "tables/forbidden_inputs.csv",
    "schema/EWInputCard.schema.json",
    "schema/RenormalizationSchemeCard.schema.json",
    "schema/DiagramFamilyLedger.schema.json",
    "schema/DeltaRResult.schema.json",
    "evaluator_stub/ew_self_energy_evaluator_contract.py",
    "fixtures/valid_contract_fixture.json",
    "fixtures/invalid_forbidden_inputs_fixture.json",
    "results/CLOSURE_STATEMENT.json",
    "paper_drop_in/Paper33_or_Microphysics_OSW_Evaluator_Contract_DropIn.tex",
]

REQUIRED_CONVENTIONS = {
    "on_shell_renormalization_scheme",
    "finite_part_convention",
    "renormalization_scale_convention",
    "subtraction_prescription",
    "Goldstone_diagram_family_content",
    "ghost_diagram_family_content",
    "gauge_boson_diagram_family_content",
    "tadpole_convention",
    "fermionic_pieces",
    "counterterm_matching_scheme",
    "covariance_protocol",
    "Ward_identity_checks",
    "gauge_parameter_cancellation_checks",
}

FORBIDDEN = {
    "measured_M_W_value",
    "DIZET_ZFITTER_aggregate_output",
    "published_total_SM_M_W_as_component_value",
    "fitted_counterterm",
    "post_hoc_tolerance",
    "four_over_5063_weak_angle_shortcut",
    "measured_sin2theta_eff",
}

DIAGRAM_FAMILIES = {
    "running_alpha", "fermion_self_energy", "W_self_energy", "Z_self_energy",
    "gamma_gamma_vacuum_polarization", "gamma_Z_mixing", "vertex_terms", "box_terms",
    "Goldstone_loops", "ghost_loops", "gauge_boson_loops", "Higgs_loops",
    "tadpoles", "mass_counterterms", "charge_counterterm", "weak_angle_counterterm",
}


def fail(msg):
    print(f"EW_OS_W_RENORMALIZED_SELF_ENERGY_CONTRACT_FAIL: {msg}")
    sys.exit(1)


def main():
    for rel in REQUIRED_FILES:
        if not (ROOT / rel).exists():
            fail(f"missing required file: {rel}")

    ledger = json.loads((ROOT / "CLAIM_LEDGER.json").read_text())
    exports = ledger["exports"]
    if exports["Export_OSW_renormalized_EW_self_energy_evaluator_contract"] != 1:
        fail("contract export not set")
    for k in [
        "Export_OSW_APF_internal_DeltaRhobarW_evaluated",
        "Export_OSW_APF_internal_delta_r_rem_evaluated",
        "Export_OSW_APF_internal_full_loop_derivation",
        "Export_numeric_MW_prediction_from_this_pack",
        "Export_fitted_counterterm",
    ]:
        if exports[k] != 0:
            fail(f"non-claim violated: {k}")

    if set(ledger["required_conventions"]) != REQUIRED_CONVENTIONS:
        fail("required convention set mismatch")
    if set(ledger["forbidden_inputs"]) != FORBIDDEN:
        fail("forbidden input set mismatch")

    target = ledger["target_intervals"]
    if target["DeltaRhobarW_MZ"] != {"min": -1.260, "max": -1.136, "units": "dimensionless normalized APF route units"}:
        fail("DeltaRhobarW target interval mismatch")
    if target["Delta_r_rem_alpha"]["min"] != 0.003518 or target["Delta_r_rem_alpha"]["max"] != 0.003839:
        fail("Delta_r_rem_alpha interval mismatch")
    if target["Delta_r_rem_target"]["min"] != 0.009409 or target["Delta_r_rem_target"]["max"] != 0.009730:
        fail("Delta_r_rem target interval mismatch")
    if ledger["diagnostic_boundary"]["DeltaRhobarW_bos_diag"] != 2.485:
        fail("diagnostic scalar value mismatch")
    if ledger["diagnostic_boundary"]["promoted"] is not False:
        fail("diagnostic scalar promotion should be false")

    with (ROOT / "tables/diagram_family_ledger.csv").open(newline='') as f:
        rows = list(csv.DictReader(f))
    families = {r["family"] for r in rows}
    missing = DIAGRAM_FAMILIES - families
    if missing:
        fail(f"diagram families missing: {sorted(missing)}")
    if any(r["required"] != "yes" for r in rows):
        fail("all diagram rows must be required in contract v1")

    with (ROOT / "tables/forbidden_inputs.csv").open(newline='') as f:
        forbidden_rows = {r["forbidden_input"] for r in csv.DictReader(f)}
    if forbidden_rows != FORBIDDEN:
        fail("forbidden inputs CSV mismatch")

    fixture = json.loads((ROOT / "fixtures/valid_contract_fixture.json").read_text())
    if fixture["input_card"]["target_value_consumed"] is not False:
        fail("valid fixture consumes target")
    if fixture["scheme_card"]["scheme"] != "on_shell":
        fail("valid fixture scheme is not on_shell")
    if set(fixture["diagram_ledger"]["families"]) != DIAGRAM_FAMILIES:
        fail("valid fixture diagram families mismatch")

    bad_fixture = json.loads((ROOT / "fixtures/invalid_forbidden_inputs_fixture.json").read_text())
    if not bad_fixture["input_card"].get("target_value_consumed"):
        fail("invalid fixture does not exercise target consumption")
    if "fitted_counterterm" not in bad_fixture["input_card"]:
        fail("invalid fixture must include fitted_counterterm")

    print("EW_OS_W_RENORMALIZED_SELF_ENERGY_CONTRACT_PASS")
    print("exports.contract=1")
    print("exports.value_evaluated=0")
    print("diagram_families=16")
    print("forbidden_inputs=7")
    print("target_interval_DeltaRhobarW=[-1.260,-1.136]")


if __name__ == "__main__":
    main()
