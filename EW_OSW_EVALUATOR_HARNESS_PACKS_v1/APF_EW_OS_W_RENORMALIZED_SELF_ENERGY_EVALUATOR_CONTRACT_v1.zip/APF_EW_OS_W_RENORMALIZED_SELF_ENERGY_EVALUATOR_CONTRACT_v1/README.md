# APF EW OS-W Renormalized Self-Energy Evaluator Contract v1

This pack closes the **contract layer** for the OS-W APF-internal electroweak self-energy route.

It does **not** evaluate a new electroweak value. It specifies the convention, diagram family ledger, forbidden-input ledger, schema, and verifier that a future evaluator must satisfy before the OS-W APF-internal `DeltaRhobarW` or `delta_r_rem` route can be evaluated.

## Why this pack exists

LATEST-78 closed the current-depth boundary: the locally runnable scalar-B0 helper returned

```text
DeltaRhobarW_bos_diag = 2.485
```

against the frozen target interval

```text
DeltaRhobarW(MZ) in [-1.260, -1.136]
Delta_r_rem_alpha in [0.003518, 0.003839]
```

and was refused as an APF-internal component because it lacked the full renormalized self-energy convention.

This pack answers that refusal by defining the required evaluator contract.

## Positive claim

```text
Export_OSW_renormalized_EW_self_energy_evaluator_contract = 1
```

## Preserved non-claims

```text
Export_OSW_APF_internal_DeltaRhobarW_evaluated = 0
Export_OSW_APF_internal_delta_r_rem_evaluated = 0
Export_OSW_APF_internal_full_loop_derivation = 0
Export_numeric_MW_prediction_from_this_pack = 0
```

## Verification

Run:

```bash
python scripts/check_ew_self_energy_contract.py
```

Expected:

```text
EW_OS_W_RENORMALIZED_SELF_ENERGY_CONTRACT_PASS
```
