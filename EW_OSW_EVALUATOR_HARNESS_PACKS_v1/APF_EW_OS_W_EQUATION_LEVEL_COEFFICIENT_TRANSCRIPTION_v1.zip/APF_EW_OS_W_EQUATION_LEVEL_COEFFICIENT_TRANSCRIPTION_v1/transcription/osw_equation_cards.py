"""Equation-card layer for the OS-W APF-internal route.

This module provides only equation-card validation and a few previously landed symbolic kernels.
It intentionally refuses finite-remainder evaluation until all source-certified coefficient values land.
"""
from dataclasses import dataclass
from typing import Iterable, Sequence
import math

FORBIDDEN_INPUTS = {
    "measured_M_W_value",
    "DIZET_ZFITTER_aggregate_output",
    "published_total_SM_M_W_as_component_value",
    "fitted_counterterm",
    "post_hoc_tolerance",
    "four_over_5063_weak_angle_shortcut",
    "measured_sin2theta_eff",
}

REQUIRED_REMAINDER_FAMILIES = {
    "W_transverse_self_energy",
    "Z_transverse_self_energy",
    "gamma_Z_mixing",
    "gamma_gamma_hadronic_residual",
    "vertex_terms",
    "box_terms",
    "charged_Goldstone_loops",
    "neutral_Goldstone_loops",
    "ghost_loops",
    "gauge_boson_loops",
    "Higgs_loops",
    "tadpoles",
    "mass_charge_weak_angle_counterterms",
    "higher_order_QCD_EW_screening",
}

@dataclass(frozen=True)
class EquationCard:
    family: str
    equation_role: str
    transcription_status: str
    coefficient_values_imported: bool = False
    target_consumed: bool = False
    forbidden_inputs_present: bool = False

class ForbiddenInputError(ValueError):
    pass

class CoefficientValueImportRequired(RuntimeError):
    pass

def validate_no_forbidden_inputs(input_keys: Iterable[str]) -> None:
    bad = sorted(set(input_keys) & FORBIDDEN_INPUTS)
    if bad:
        raise ForbiddenInputError("Forbidden target-consuming inputs present: " + ", ".join(bad))

def delta_r_os_decomposition(delta_alpha: float, delta_rho: float, delta_r_rem: float, sW2: float, cW2: float) -> float:
    """Symbolic OS decomposition helper; allowed only when components are externally supplied by audited cards."""
    return delta_alpha - (cW2 / sW2) * delta_rho + delta_r_rem

def delta_alpha_leptonic_one_loop(alpha0: float, q2: float, lepton_masses: Sequence[float]) -> float:
    return sum(alpha0/(3.0*math.pi)*(math.log(q2/(m*m))-5.0/3.0) for m in lepton_masses)

def delta_rho_top_leading(GF: float, mt: float) -> float:
    return 3.0 * GF * mt * mt / (8.0 * math.sqrt(2.0) * math.pi * math.pi)

def A0bar(m2: float, mu2: float) -> float:
    return m2 * (1.0 - math.log(m2/mu2))

def B0bar_real_region_placeholder(*args, **kwargs):
    raise CoefficientValueImportRequired(
        "B0bar numerical evaluation belongs to the finite-PV substrate; complex threshold conventions must be explicit."
    )

def validate_equation_cards(cards: Sequence[EquationCard]) -> dict:
    families = {c.family for c in cards}
    missing = sorted(REQUIRED_REMAINDER_FAMILIES - families)
    if missing:
        raise ValueError({"missing_remainder_families": missing})
    for c in cards:
        if c.target_consumed or c.forbidden_inputs_present:
            raise ForbiddenInputError(f"target-consuming equation card: {c.family}")
    return {
        "equation_cards_declared": len(cards),
        "remainder_family_slots_declared": len(families & REQUIRED_REMAINDER_FAMILIES),
        "full_remainder_coefficients_transcribed": False,
        "value_evaluated": False,
    }

def evaluate_full_remainder(*args, **kwargs):
    raise CoefficientValueImportRequired(
        "Equation cards are declared, but source-certified coefficient values are not fully imported in v1."
    )
