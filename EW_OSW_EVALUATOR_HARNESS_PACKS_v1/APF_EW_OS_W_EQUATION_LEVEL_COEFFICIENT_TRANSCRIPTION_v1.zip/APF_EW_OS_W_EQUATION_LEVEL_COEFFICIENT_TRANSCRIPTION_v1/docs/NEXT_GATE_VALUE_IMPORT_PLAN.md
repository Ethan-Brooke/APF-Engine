# Next gate: family-by-family coefficient value import

The next pack should import coefficient values family-by-family against the equation cards in this pack.

Required first landing order:

1. W/Z transverse self-energy coefficient cards.
2. Gamma-Z and gamma-gamma residual coefficient cards.
3. Vertex and box cards.
4. Goldstone / ghost / gauge cancellation cards as one gauge-closure group.
5. Higgs + tadpole + counterterm assembly cards.
6. Higher-order QCD/EW screening ledger.

No `Delta_r_rem` export is allowed until all source-required families are filled and covariance/gauge-cancellation gates pass.
