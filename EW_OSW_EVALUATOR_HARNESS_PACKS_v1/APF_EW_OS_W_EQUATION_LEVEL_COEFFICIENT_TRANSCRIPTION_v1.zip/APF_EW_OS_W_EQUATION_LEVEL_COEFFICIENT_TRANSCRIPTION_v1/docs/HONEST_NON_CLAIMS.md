# Honest non-claims

This pack does not export an APF-internal evaluated electroweak value.

Non-claims preserved:

```text
Export_OSW_full_remainder_family_coefficients_transcribed = 0
Export_OSW_APF_internal_DeltaRhobarW_evaluated = 0
Export_OSW_APF_internal_delta_r_rem_evaluated = 0
Export_OSW_APF_internal_full_loop_derivation = 0
Export_OSW_full_reviewed_formula_evaluator = 0
Export_numeric_MW_prediction_from_this_pack = 0
Export_DIZET_replacement_evaluator = 0
Export_fitted_counterterm = 0
```

The target windows remain audit comparators only. They are not allowed as sources for coefficient values, tolerances, counterterms, signs, or finite parts.
