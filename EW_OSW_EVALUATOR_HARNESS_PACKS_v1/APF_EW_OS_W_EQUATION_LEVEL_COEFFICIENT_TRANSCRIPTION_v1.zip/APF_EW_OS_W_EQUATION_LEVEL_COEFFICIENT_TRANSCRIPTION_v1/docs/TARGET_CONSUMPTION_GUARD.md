# Target-consumption guard

Forbidden inputs:

```text
measured_M_W_value
DIZET_ZFITTER_aggregate_output
published_total_SM_M_W_as_component_value
fitted_counterterm
post_hoc_tolerance
four_over_5063_weak_angle_shortcut
measured_sin2theta_eff
```

The loader rejects any equation card or input card carrying these keys.
