# Integrator note

This pack is the equation-card layer. It should be landed after the source-certified coefficient import pack and before any family-by-family coefficient-value import.

Expected landing behavior:

1. Register the equation-card schema.
2. Register the symbol dictionary.
3. Preserve the fail-closed loader.
4. Do not wire a numeric evaluator yet.
5. Keep `target_consumed = false` in every downstream source/equation/value card.

The next gate is `APF_EW_OS_W_FAMILY_BY_FAMILY_COEFFICIENT_VALUE_IMPORT_v1`.
