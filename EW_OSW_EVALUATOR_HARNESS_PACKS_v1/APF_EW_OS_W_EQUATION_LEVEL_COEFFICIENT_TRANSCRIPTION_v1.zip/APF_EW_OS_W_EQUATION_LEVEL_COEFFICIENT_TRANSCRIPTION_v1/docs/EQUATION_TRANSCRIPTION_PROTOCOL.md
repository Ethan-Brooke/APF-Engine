# Equation transcription protocol

A reviewed equation may enter the APF-internal OS-W evaluator only if its card declares:

- family name;
- source identifier;
- equation/location identifier;
- renormalization scheme;
- finite-part convention;
- scale convention;
- sign convention;
- symbol dependencies;
- whether coefficient values are present;
- whether the card consumes any forbidden target input.

Equation cards are not numeric evaluations. A card may provide a symbolic expression while refusing coefficient-value import until a source-certified coefficient value card lands.
