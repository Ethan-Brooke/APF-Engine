# OS-W Equation-Level Transcription Boundary Theorem

Let an OS-W reviewed-formula evaluator be assembled from equation cards `E_i` and coefficient-value cards `K_i`.

This pack establishes the admissible equation-card layer: a future evaluator may reference a component family only if the family has a declared equation card with source, scheme, sign, scale, finite-part and dependency conventions.

However, an equation card is not a coefficient-value card and is not an evaluated self-energy. Therefore:

\[
\operatorname{Export}_{m equation\ cards}=1
\]

does not imply

\[
\operatorname{Export}_{\Delta r_{m rem}\ m evaluated}=1.
\]

The evaluated route opens only after all coefficient-value cards are filled, gauge/counterterm gates pass, and target-consumption guards certify `target_consumed = false`.
