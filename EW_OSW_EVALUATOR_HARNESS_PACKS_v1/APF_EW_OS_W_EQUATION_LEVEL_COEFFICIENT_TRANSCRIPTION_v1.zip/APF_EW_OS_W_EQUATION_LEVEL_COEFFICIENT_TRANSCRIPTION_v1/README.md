# APF EW OS-W Equation-Level Coefficient Transcription v1

Gate: **equation-level coefficient transcription scaffold** for the APF-internal OS-W route.

This pack advances the OS-W route from source-certified coefficient import to an equation-card layer:

```text
source-certified family cards
  -> normalized equation cards
  -> symbol dictionary
  -> fail-closed transcription loader
```

It does **not** evaluate `DeltaRhobarW`, `Delta_r_rem`, `Delta_r_OS`, or `M_W`.

## What closes

- Core equation cards are transcribed for:
  - OS decomposition
  - leptonic running-alpha one-loop kernel
  - leading top custodial-breaking `Delta rho` kernel
  - finite `A0bar` scalar-integral substrate
  - finite `B0bar` scalar-integral substrate
- Fourteen finite-remainder families receive source-linked equation-card slots and required symbol/dependency signatures.
- Runtime guard rejects target-consuming inputs.

## What remains open

The actual family-by-family coefficient values for the 14 finite-remainder families remain source-required. This pack freezes the equation landing surface; it does not claim to have filled the coefficients.

## Verifier

```bash
python scripts/check_osw_equation_level_coefficient_transcription.py
```
