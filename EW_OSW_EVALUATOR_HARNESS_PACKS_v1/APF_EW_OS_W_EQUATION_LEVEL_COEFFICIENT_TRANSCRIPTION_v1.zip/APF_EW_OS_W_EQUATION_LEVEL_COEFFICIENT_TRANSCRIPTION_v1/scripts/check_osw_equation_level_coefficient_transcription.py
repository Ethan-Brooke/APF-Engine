#!/usr/bin/env python3
import csv, json, sys, importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_FAMILIES = {
    "W_transverse_self_energy",
    "Z_transverse_self_energy",
    "gamma_Z_mixing",
    "gamma_gamma_hadronic_residual",
    "vertex_terms",
    "box_terms",
    "charged_Goldstone_loops",
    "neutral_Goldstone_loops",
    "ghost_loops",
    "gauge_boson_loops",
    "Higgs_loops",
    "tadpoles",
    "mass_charge_weak_angle_counterterms",
    "higher_order_QCD_EW_screening",
}
FORBIDDEN = {
    "measured_M_W_value",
    "DIZET_ZFITTER_aggregate_output",
    "published_total_SM_M_W_as_component_value",
    "fitted_counterterm",
    "post_hoc_tolerance",
    "four_over_5063_weak_angle_shortcut",
    "measured_sin2theta_eff",
}

def rows(path):
    with open(path, newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))

def check_claim_ledger():
    d = json.loads((ROOT/'CLAIM_LEDGER.json').read_text())
    assert d['positive_exports']['Export_OSW_equation_level_transcription_scaffold'] == 1
    assert d['positive_exports']['Export_OSW_core_equation_cards_transcribed'] == 1
    assert d['preserved_nonclaims']['Export_OSW_APF_internal_delta_r_rem_evaluated'] == 0
    assert d['preserved_nonclaims']['Export_numeric_MW_prediction_from_this_pack'] == 0
    assert set(d['forbidden_inputs']) == FORBIDDEN
    assert d['equation_cards'] == 19
    assert d['source_required_remainder_family_cards'] == 14

def check_equation_cards():
    r = rows(ROOT/'ledgers/EQUATION_LEVEL_TRANSCRIPTION_CARDS.csv')
    assert len(r) == 19
    remainder = [x for x in r if x['equation_role'] == 'finite_remainder_family']
    assert len(remainder) == 14
    assert {x['family'] for x in remainder} == EXPECTED_FAMILIES
    assert all(x['target_consumed'] == 'false' for x in r)
    assert all(x['forbidden_inputs_present'] == 'false' for x in r)
    assert all(x['coefficient_values_imported'] in {'false','prior_kernel_only'} for x in r)
    core = {x['family']: x['transcription_status'] for x in r if x['equation_role'] != 'finite_remainder_family'}
    for needed in ['OS_decomposition','running_alpha_leptonic','leading_top_delta_rho','PV_A0bar_finite','PV_B0bar_finite']:
        assert needed in core

def check_symbols_and_forbidden():
    s = rows(ROOT/'ledgers/SYMBOL_DICTIONARY.csv')
    assert len(s) >= 8
    assert {'Delta_r_OS','Delta_alpha','Delta_rho','Delta_r_rem'} <= {x['symbol'] for x in s}
    f = rows(ROOT/'ledgers/FORBIDDEN_INPUT_LEDGER.csv')
    assert {x['forbidden_input'] for x in f} == FORBIDDEN
    assert all(x['runtime_guard'] == 'reject_if_present' for x in f)

def check_fixtures():
    valid = json.loads((ROOT/'fixtures/valid_equation_transcription_fixture.json').read_text())
    assert len(valid['cards']) == 14
    assert not (set(valid['input_keys']) & FORBIDDEN)
    invalid = json.loads((ROOT/'fixtures/invalid_forbidden_equation_fixture.json').read_text())
    assert set(invalid['input_keys']) & FORBIDDEN

def check_module():
    path = ROOT/'transcription/osw_equation_cards.py'
    spec = importlib.util.spec_from_file_location('osw_equation_cards', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    try:
        mod.validate_no_forbidden_inputs(['alpha0','measured_M_W_value'])
    except mod.ForbiddenInputError:
        pass
    else:
        raise AssertionError('forbidden input did not raise')
    # Simple deterministic checks of prior kernels and decomposition.
    assert abs(mod.delta_r_os_decomposition(1.0, 0.1, 0.01, 0.25, 0.75) - 0.71) < 1e-12
    assert mod.delta_rho_top_leading(1.1663787e-5, 173.0) > 0
    assert mod.A0bar(4.0, 1.0) < 0

def check_closure():
    d = json.loads((ROOT/'results/CLOSURE_STATEMENT.json').read_text())
    assert d['status'] == 'EQUATION_LEVEL_COEFFICIENT_TRANSCRIPTION_CLOSED_NO_VALUE'
    assert d['equation_cards'] == 19
    assert d['source_required_remainder_family_cards'] == 14
    assert d['nonclaims']['Export_OSW_APF_internal_DeltaRhobarW_evaluated'] == 0

def main():
    checks = [check_claim_ledger, check_equation_cards, check_symbols_and_forbidden, check_fixtures, check_module, check_closure]
    for c in checks:
        c()
    print('EW_OS_W_EQUATION_LEVEL_COEFFICIENT_TRANSCRIPTION_PASS')
    print('equation_cards=19')
    print('core_cards_transcribed=5')
    print('source_required_remainder_family_cards=14')
    print('forbidden_inputs=7')
    print('exports.value_evaluated=0')
    print('next_gate=APF_EW_OS_W_FAMILY_BY_FAMILY_COEFFICIENT_VALUE_IMPORT_v1')

if __name__ == '__main__':
    main()
